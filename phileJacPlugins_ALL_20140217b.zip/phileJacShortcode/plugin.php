<?php
// phileJacShortcode.php
// ---------------------------------------
require_once PLUGINS_DIR.'/phileJacShortcode/lib/shortcodes.php';
// ---------------------------------------
// This plugin class must be loaded before all shortcodes.
// There are no shortcodes in this class.  This is just an engine that will
// execute all registered shortcodes by other plugins.
// The shortcodes are executed in the hook before_parse_content
// ---------------------------------------
// The engine provides this function that the polugins use to register their shortcodes
// add_shortcode('shortcode text name', 'function to execute');
// i.e. 
// add_shortcode('show_current_year', 'show_current_year');
// See sy_showyear.php for example of sinplest shortcode
// See other files for more shortcodes
// ---------------------------------------
class PhileJacShortcode extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
  /*
  This will execute ALL registered shortcodes.
  NOTE: SHORTCODES ARE DONE BEFORE MARKDOWN......
  */
	public function __construct() {
                \Phile\Event::registerEvent('before_parse_content', $this);
		\Phile\Event::registerEvent('after_parse_content', $this);
		
                // go and get the settings for the site
		$this->config = \Phile\Registry::get('Phile_Settings');

              add_shortcode('show_current_year', array($this, 'show_current_year'));  
	}

	public function on($eventKey, $data = null) {
            
            if ($eventKey == 'before_parse_content') {
                    //Event::triggerEvent('before_parse_content', array('content' => $this->content, 'page' => &$this)); 
                //global $shortcode_tags; //from lib
                //\Phile\Utility::printnice($shortcode_tags, $exit = false, $type = 'print');  
                $out = do_shortcode($data['content']);
                $data['content'] = $out;		
            }
        }

        
        function show_current_year(){
            return date('Y');
        }
        
}
