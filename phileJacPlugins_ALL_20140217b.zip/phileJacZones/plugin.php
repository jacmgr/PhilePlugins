<?php
// PhileJacZones.php
// TEMPLATE ZONES
// ---------------------------------------
/* 
 TODO:    FIX SO HEIRARCHICAL
 
Zones are identified in layout.  They should be heirarchical, but no yet.
Each zone is essentially a PAGEFILE NAME without the extension.  For each zone will
render zone page to a variable of the name {{ zones.zonename }} and place it in the main view.

Zones there for can have templates, but NOT layouts.  Use Layout of main page "content"

Array is $key = zonename used in layout (zone.zonename)
$value = the page filename to be used for content of the zone (without extension (.md)).

Zone files are automatically(?) excluded from the menu lists if the navigation addon does so using config[zones]
		
NOT YET IMPLEMENTED:   The ZONE PAGES should be heirarchical, look for closest file in the tree.
RIght now just getting the exact file name in the config array and using it on all pages.

*/
class PhileJacZones extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
     //could put this in plugin config file, but lets not,	
    // See cnfig.php for default Zones
    private $zones = array();
    /*
    * 
    * SHOULD NOT ENTER ZONES HERE
    * ENTER your zones in your site config.php using format shown below
    */
    /*
    $config['zones'] = array( 'zonename' => 'pagename', 
                              'bottom' =>'bottomXXX',
                          'bootomleft'=>'bottomleft',
                        );
    */
    private $UseZones = false;
    
	public function __construct() { 
            \Phile\Event::registerEvent('request_uri', $this);
            \Phile\Event::registerEvent('config_loaded', $this);
            \Phile\Event::registerEvent('template_engine_registered', $this);  
	}
        
	public function on($eventKey, $data = null) {
            
            if ($eventKey == 'request_uri') {
               //Event::triggerEvent('request_uri', array('uri' => $uri));          
                $this->currentpage = $data['uri'];
            
            }
            if($eventKey == 'config_loaded') {
                //Phile Settings
            	$settings = \Phile\Registry::get('Phile_Settings');
                // \Phile\Utility::printnice($settings['zones'], $exit = false, $type = 'print');
                
                if(isset($settings['zones'])){
                        $this->zones = $settings['zones'];
                        $this->UseZones = true;
		}
            }
            
            if ($eventKey == 'template_engine_registered') {
                // Event::triggerEvent('template_engine_registered', array('engine' => &$twig, 'data' => &$twig_vars));
                // \Phile\Utility::printnice($data['data'], $exit = false, $type = 'print');
                $meta = $data['data']['current_page']->getMeta()->getAll();
                // \Phile\Utility::printnice($meta['filename'], $exit = false, $type = 'print');

                if( $meta['filename'] == $this->currentpage.CONTENT_EXT) {
                    if($this->UseZones) {
                        $data['data']['zones'] = $this->preparezones($this->zones);
                    }
                }
            }

        }
  
        private function preparezones($zonearray) {
            $pageRepository = new \Phile\Repository\Page(); //could use options here
            /*
            findByPath($path)
            getPage($filePath)
            */
            $results = null;
         	foreach ($zonearray as $zonename => $zonepage)
		{ 
                    
                    //this function is protected so can;t use
                    //would like to use since findby path checks disk every time.
                    //the file sis going to be there, so why not go directly to repositroy...
                    //$page = $pageRepository->getPage($zonepage);
                    $page = $pageRepository->findByPath($zonepage);
                    //if($zonename='featured')\Phile\Utility::printnice($zonepage, $exit = false, $type = 'print');
                    $results[$zonename] = null;
                    //page model get content parses with before and after.
                    if(isset($page)) $results[$zonename] = $page->getContent();
                    if($zonename == 'featured') { 
                        ## \Phile\Utility::printnice($zonepage, $exit = false, $type = 'print');
                        ## \Phile\Utility::printnice($results[$zonename], $exit = false, $type = 'print'); 
                    }
                 } 
            
            return $results;
        }
        
}
