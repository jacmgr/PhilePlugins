<?php
// PhileJacShortcodeGallery.php
// ---------------------------------------
// The plugin class phileJacShortcode.php must be loaded and activated before all shortcodes.
// The shortcodes are executed in the hook before_parse_content OF phileJacShortcode.php.
/*
   AMAZON
[linkiframeAmazon asins=0547517653]

*/
// ---------------------------------------
// See other files for more shortcodes
// ---------------------------------------
class PhileJacShortcodeGallery extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
  /*
  NOTE: SHORTCODES ARE DONE BEFORE MARKDOWN......
  */
	public function __construct() {
            
                \Phile\Event::registerEvent('config_loaded', $this);	
                \Phile\Event::registerEvent('request_uri', $this);
            
                //register the shortcode in phileJacShortcode.php do_shortcode
		//this format to add functions that are in this class
		add_shortcode('jactimthumb', array($this, 'funcjactimthumb'));
		add_shortcode('jacgalleryfromfolder', array($this, 'funcjacgalleryfromfolder'));   
	
                $this->plugin_path = dirname(__FILE__);
        }
        
        //each plugin extending plugin\AbstractPlugin MUST have an "on" Method, even if does nothing
      	public function on($eventKey, $data = null) {

           if ($eventKey == 'config_loaded') {
                //Event::triggerEvent('config_loaded');                       
            	$this->settings = $this->settings = \Phile\Registry::get('Phile_Settings');
		$this->root_dir = ROOT_DIR;
		$this->files_dir = 'files';  //default.  Somehow should change it in shortcode
		$this->contentfolder = '/content'; //need to use to specify full location
		$this->TimthumbDir = dirname($this->settings['base_url']).'/timthumb';
		$this->Timthumb_NoImage = $this->TimthumbDir.'/'.'noimage.jpg';
		$this->javascriptSB = $this->settings['base_url'].'/themes'.'/shadowbox-3.0.3/';
		// problem when theme is in non standard folder location
		//conside removeing these lines if shadowbox is in standard theme location.
		$file = str_replace('\\', '/', THEMES_DIR . 'shadowbox-3.0.3');
                $this->javascriptSB = 'http://'.$_SERVER['HTTP_HOST'].str_replace($_SERVER['DOCUMENT_ROOT'], '', $file);
            }
            if ($eventKey == 'request_uri') {
                //Event::triggerEvent('request_uri', array ($uri)); 
                $uri = $data['uri'];
                //builds form html for use in before parse and processes form and header on success post
                $this->currentpage = CONTENT_DIR.'/'.$uri; 
                $this->request_url($uri);
            }
            
       }

	public function after_load_content(&$file, &$content)
	{
		$this->currentpage = $file;
		$this->currentcontent = $content;
	}

        
	public function request_url(&$url)
	{
		/*
		 if this is a timthumb request to the image location then we want to avoid the 404
		 If url has file extension of .jpg, and others then just show it.
		*/
		$this->url = $url;
		// CHECK EXTENSION
		$file_parts = pathinfo($url);
		if(isset($file_parts['extension']))
		{
			if(in_array($file_parts['extension'], array('jpg', 'JPG','jpeg', 'JPEG', 'png','PNG', 'gif','GIF')))
			{
				$url = str_replace('%20', " ", $url);
				$file = CONTENT_DIR . $url;
				$imginfo = getimagesize($file);
				header('Content-type: '.$imginfo['mime']);
				ob_clean(); // clean the output buffer
				flush();
				readfile($file);
					// Don't continue to render template
				exit;					
			}
		}
	}        
        
 // ---------------------------------------	
// jactimthmb
// Displays one image from shortcode jactimthumb
	public function funcjactimthumb($atts, $content = null) 
	{
	/*extract( shortcode_atts( array(
		'name' => '',
	), $atts ) );
	*/
	$args = shortcode_atts( array(
		'name' => '',
		'rootfolder' => '',
		), 
		$atts );
	$tt_args_allowed = array(
                'width' => '425',
                'height' => '',
                'crop' => '',
                'filter' => '',
                'sharpen' => '',
                'zoom' => '',
                'quality' => '70',
                'align' => 'center',
                'alt' => '',
                'title' => '',
                'caption' => '',
                'link' => 0,
                'hspace' => '5',
                'vspace' => '5',
        );
  //merge with user supplied args
	$tt_args_allowed = array_merge($tt_args_allowed, $atts);

	//determne the filename
	$filename = $args['name'];
  $rootfolder = $args['rootfolder'];
  
	if ($filename == '') { $filename = $atts[0]; unset($atts[0]); }
	if ($rootfolder != '')$rootfolder=$rootfolder.'/';
	//assumes all photos are in current file path
  $fieldPATH = dirname($this->currentpage).'/'. $rootfolder;
  $filesDIR = $fieldPATH.''.$this->files_dir;
  //$fieldURL = $this->settings['base_url'];
	//$fieldURL = $fieldURL.$this->contentfolder.'/'.dirname($this->url);  
	//$filesURL = $fieldURL.'/'.$this->files_dir;		
	/*
	
	This works... so if the current folder has the rootdir in it then 
	don;t use rootdir otherwise use i
	
	http://localhost/picojac2/timthumb/timthumb.php?src=http://localhost/picojac2/urichip/content//content/posts//files/puppy/2013-09-18 16.34.48.jpg&w=400&q=70
	
	*/
	if ($rootfolder != ''){
		//echo 'you got a match';
				//$fieldURL = $fieldURL.$this->contentfolder.'/'.$rootfolder;
				//$filesURL = $fieldURL. '/'.$this->files_dir;
  $fieldURL = $this->settings['base_url'];
	$fieldURL = $fieldURL.$this->contentfolder.'/'.$rootfolder;  
	$filesURL = $fieldURL.'/'.$this->files_dir;	
	}
	else
	{
  $fieldURL = $this->settings['base_url'];
	$fieldURL = $fieldURL.$this->contentfolder.'/'.dirname($this->url);  
	$filesURL = $fieldURL.'/'.$this->files_dir;	
	}
	
	
	
	//echo $rootfolder;
	//echo '<br>fieldPATH is:'.$fieldPATH;
	//echo '<br>filesDIR is:'.$filesDIR;
	//echo '<br>fieldURL is:'.$fieldURL;
	//exit;
	
	// Path to the timthumb.php directory
	$tt_path = $this->TimthumbDir;
	$tt_errorimage = $this->Timthumb_NoImage;
	
  // convert to url
  //adds timthumb to the url
	$filename_image = $filesURL.'/'.$filename;
  $ext = strtolower(pathinfo(trim($filename_image), PATHINFO_EXTENSION));
  
	//extract to individual vars	used below			
 	extract($tt_args_allowed);   
	if ($link == 'false') $link = 0;
  if (($ext == "jpg" || $ext == "jpeg" || $ext == "png" || $ext == "gif")) {
                $myimage = trim($filename_image);
                if($width)   $myimage .= '&w='  . $width;
                if($height)  $myimage .= '&h='  . $height;
                if($crop)    $myimage .= '&a='  . $crop;
                if($filter)  $myimage .= '&f='  . $filter;
                if($sharpen) $myimage .= '&s='  . $sharpen;
                if($zoom)    $myimage .= '&zc=' . $zoom;
                if($quality) $myimage .= '&q='  . $quality;

		if ($caption != "") {
			if ($align == "center") $align = "picframe center";
			if ($align == "left") $align = "picframe left";
			if ($align == "right") $align = "picframe right";
			$imgtag = "<img src='$tt_path/timthumb.php?src=$myimage' alt='$alt' title='$title' width='$width' />";
			if ($link){$imgtag = "<a href=$filename_image target=new>$imgtag</a>"; }
     	$out = "<div class='$align' style='width: $width'>$imgtag<p class='caption-text'>$caption</p></div>";

		} else if ($caption == "") {

			if ($align == "center") $align = "center";
			if ($align == "left") $align = "left";
			if ($align == "right") $align = "right";
			$imgtag = "<img src='$tt_path/timthumb.php?src=$myimage' alt='$alt' title='$title' width='$width' hspace='$hspace' vspace='$vspace' class='$align' />";
			if ($link){$imgtag = "<a href=$filename_image target=new>$imgtag</a>"; }
			$out = "<div class='$align' style='width: $width;'>$imgtag</div>";
		}
  }
  else 
  {
      $out = "<img class='$align' src='$tt_errorimage' alt='Error Image' width='$width' />";
  }
  
	return $out;
	}
	
// ---------------------------------------
// jacgalleryfromfolder
// displays a gallery for a given folder.  Uses SHADOWBOX
	public function funcjacgalleryfromfolder($atts, $content = null) 
	{
	/*extract( shortcode_atts( array(
		'folder' => '',
		'width' => 200
	), $atts ) );
	*/
	$args = shortcode_atts( array(
		'folder' => '',
		'width' => 200
		), 
		$atts );

	//args includes gallery name and thumbnail generation parameters for timthumb
	//other args for thumbnail creation will be passed to checkthumb
  //files are in the current path....
	$galleryname = $args['folder'];	
	$fieldPATH = dirname($this->currentpage).'/';
  $filesDIR = $fieldPATH.''.$this->files_dir;
  $fieldURL = $this->settings['base_url'];
	$fieldURL = $fieldURL.$this->contentfolder.'/'.dirname($this->url);  
	$filesURL = $fieldURL.'/'.$this->files_dir;
	
	$result = glob("$filesDIR/$galleryname/*.{jpg,png,gif,JPG,PNG,GIF}", GLOB_BRACE);
	$count = count($result);	
	if (isset ($args['count'])) $count = $args['count'];
	
	//Gallery exists so build it
	//method based on http://demo.steverydz.com/gallery/
	
	$out = null;
	$out .= "<div id='jacgallery'>";
	$out .= "<ul id='thumbnails'>";
	$i = 0;
	$ImageDirectory = $filesURL.'/'.$galleryname;
	foreach ($result as $pictfilename){
		$href = $ImageDirectory.'/'.basename($pictfilename);
		$thumb = $this->jacresize($args, $ImageDirectory.'/'.basename($pictfilename));
		$alt = $pictfilename;
		$out .= '<li><a href="'.$href.'" target=new rel="shadowbox[jacgallery]"><img src="'.$thumb.'" alt="'.$alt.'"></a></li>';
		$i++;
		if ($i >= $count) break;
	}
  $out .= '</ul>';
  $out .= '</div>';
  
  //using shadow box add the scripts and css
  //this is located in the THEMES FOLDER even though not a theme but it is resource used by many themes.
  //shadowbox-3.0.3
$shadowboxlocation = $this->javascriptSB;
$shadowbox = '<link rel="stylesheet" type="text/css" href="'.$shadowboxlocation.'/shadowbox.css">
<script type="text/javascript" src="'.$shadowboxlocation.'/shadowbox.js"></script>
<script type="text/javascript">
Shadowbox.init();
</script>';

	return $shadowbox.$out; 
}
// ---------------------------------------
// jacresize
// used by jacgalleryfrom folder
function jacresize($args, $filename){
	/*
	already have full good file name passed in 
	*/
	//printnice($args);
	$tt_args_allowed = array(
                'width' => '425',
                'height' => '',
                'crop' => '',
                'filter' => '',
                'sharpen' => '',
                'zoom' => '',
                'quality' => '70',
                'align' => 'center',
                'alt' => '',
                'title' => '',
                'caption' => '',
                'link' => 0,
                'hspace' => '5',
                'vspace' => '5',
        );
  //merge with user supplied args
	$tt_args_allowed = array_merge($tt_args_allowed, $args);

	//extract to individual vars	used below			
 	extract($tt_args_allowed);   
	if ($link == 'false') $link = 0;
	// Path to the timthumb.php directory
	$tt_path = $this->TimthumbDir;
	$tt_errorimage = $this->Timthumb_NoImage; // $tt_path.'/'.'noimage.jpg';
  $filename_image = $filename;
  $ext = strtolower(pathinfo(trim($filename_image), PATHINFO_EXTENSION));
  if (($ext == "jpg" || $ext == "jpeg" || $ext == "png" || $ext == "gif")) {
                $myimage = trim($filename_image);
                if($width)   $myimage .= '&w='  . $width;
                if($height)  $myimage .= '&h='  . $height;
                if($crop)    $myimage .= '&a='  . $crop;
                if($filter)  $myimage .= '&f='  . $filter;
                if($sharpen) $myimage .= '&s='  . $sharpen;
                if($zoom)    $myimage .= '&zc=' . $zoom;
                if($quality) $myimage .= '&q='  . $quality;
  }
	$imgresize = "$tt_path/timthumb.php?src=$myimage";
	
	return $imgresize;
}	       
        
}
