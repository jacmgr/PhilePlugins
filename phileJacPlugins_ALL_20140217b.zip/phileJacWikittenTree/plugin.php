<?php
// PhileJacWikittenTree.php
// Breadcrumb and File Menu Tree
// ---------------------------------------
/*
Primarily from wikitten. 
I have bastadrized it so much, should start from scratch if really need this functionality.
*/
/**
 * navigation plugin which generates a better configurable navigation with endless children navigations
 *
 * @author Ahmet Topal
 * @link http://ahmet-topal.com
 * @license http://opensource.org/licenses/MIT
 */
class PhileJacWikittenTree extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
	
	protected $_ignore = "/^\..*|^CVS$/"; // Match dotfiles and CVS
	protected $_force_unignore = false; // always show these files (false to disable)

	public function __construct() {         
            \Phile\Event::registerEvent('template_engine_registered', $this);    
	}
      
    /*  Notes:  repository getall pages supports these options.
        $options['pages_order_by'])  alpha, title, date, null (default), meta:fieldname
        $options['pages_order']  asc,desc,
    */   
	public function on($eventKey, $data = null) {
            if ($eventKey == 'template_engine_registered') {
                //Event::triggerEvent('template_engine_registered', array('engine' => &$twig, 'data' => &$twig_vars));
                 ## $dummy = $data['data']['current_page']->getMetaArray();
                 ## echo 'Current Page Meta: '.$data['data']['current_page']->getTitle();
                 ## \Phile\Utility::printnice($dummy, $exit = false, $type = 'print');
                 
                $this->config = $data['data']['config'];

                $this->currentpagename = $data['data']['current_page']->getUrl();
                //$this->currentpagename = substr($this->currentpagename,1);

                ## \Phile\Utility::printnice($this->currentpagename, $exit = false, $type = 'print');
                /*
                 This will also get all pages, but since we already have from twig vars $data we use that one.
                    Notes:  repository getall pages supports these options.
                    $options['pages_order_by'])  alpha, title, date, null (default), meta:fieldname
                    $options['pages_order']  asc,desc,
                $pageRespository = new \Phile\Repository\Page(); //could use options here
                $thepages  = $pageRespository->findAll();
                */
                $thepages = $data['data']['pages'];
                // need some array to make compatible with the tree java code array expectations
                foreach ($thepages as $page) {
                        $id = $page->getUrl();
                        $this->pages[$id ] =  $page->getMeta()->getAll();
                        $this->pages[$id ]['url'] = $id;
                        $this->pages[$id ]['filename'] = $id;
                        /*  CHECK IF IN THE SKIP FILES HERE
                         *  current
                         */
                 }
                ## \Phile\Utility::printnice($this->pages, $exit = false, $type = 'print');
		$treearray = $this->_getTreePico2();  //create array from $this->pages compatible with tree menu
		## \Phile\Utility::printnice($treearray, $exit = false, $type = 'print');
                $parts = explode('/', $this->currentpagename);
                //echo $this->currentpagename;
                ## \Phile\Utility::printnice($parts, $exit = false, $type = 'print');
		$treehtml = $this->tree($treearray, $this->config['base_url'], isset($parts) ? $parts : array());
                //string of javacode for the meniu
                $treejava = $this->getjava();  
                $treesearch = $this->treesearch();
                //assemble it all
		$data['data']['tales']['tree'] = $treesearch.$treehtml.$treejava;
                $data['data']['tales']['breadcrumb'] = $this->breadcrumb($parts, $data['data']['current_page']->getTitle());
                $data['data']['wikitten']['breadcrumb'] = $this->breadcrumbWikitten($parts, $data['data']['current_page']->getTitle());
             }
	}
	

	function breadcrumb($parts, $pagetitle=null, $is_dir = false)
	{
		if (isset($_GET['source']))	{$sourcelink = $this->config['base_url'].'/'.$this->currentpagename; }
		$out = '
				<div class="breadcrumbs">';
				
    $out .='<ul class="unstyled">
        <li>
            <a href="'. $this->config['base_url'] .'"><i class="icon-home icon-white"></i>home</a>
        </li>';

    $path = array();

    $i = 0;

    foreach ($parts as $part): 
       $path[] = $part;
       $url = $this->config['base_url'] . "/" . join("/", $path);
            $out .='<li>
                <a href="'. htmlspecialchars($url, ENT_QUOTES, 'UTF-8') .'">';
                    if (++$i == count($parts) && !$is_dir):
                        $out .='<i class="icon-file icon-white"></i>';
                    else: 
                        $out .='<i class="icon-folder-open icon-white"></i>';
                    endif;
                    $out .= $part;
                $out .= '</a>
            </li>';
        endforeach;
    
    if ($pagetitle) $out .= '<li><strong>'.$pagetitle.'</strong></li>';
    
    $out .= '</ul>

		</div>';

		return $out;		
	}
	function breadcrumbWikitten($parts, $pagetitle=null, $is_dir = false)
	{
		$sourcelink = '?source=true';
		if (isset($_GET['source']))	{$sourcelink = $this->config['base_url'].'/'.$this->currentpagename; }
		$out = '
				<div class="breadcrumbs">

        		<div class="pull-right">
            	<!-- <a href="#" class="btn btn-mini btn-inverse" id="toggle">Toggle source</a> -->
            	<a href="'.$sourcelink.'" class="btn btn-mini btn-inverse" id="XXXtoggle">Toggle source</a>
        		</div>';
    $out .='<ul class="unstyled">
        <li>
            <a href="'. $this->config['base_url'] .'"><i class="icon-home icon-white"></i> /wiki</a>
        </li>';

    $path = array();

    $i = 0;

    foreach ($parts as $part): 
       $path[] = $part;
       $url = $this->config['base_url'] . "/" . join("/", $path);
            $out .='<li>
                <a href="'. htmlspecialchars($url, ENT_QUOTES, 'UTF-8') .'">';
                    if (++$i == count($parts) && !$is_dir):
                        $out .='<i class="icon-file icon-white"></i>';
                    else: 
                        $out .='<i class="icon-folder-open icon-white"></i>';
                    endif;
                    $out .= $part;
                $out .= '</a>
            </li>';
        endforeach;
    
    if ($pagetitle) $out .= '<li><strong>'.$pagetitle.'</strong></li>';
    
    $out .= '</ul>
    <div class="clear"></div>
		</div>';

		return $out;		
	}	

##
	# HELPER FUNCTIONS FOR TREE
	##
	
        ##  ------------------------------------------------------
        function treesearch()
	{
		$out = <<<ENDTREESEARCH
<div id="tree-filter">
    <input type="text" id="tree-filter-query" placeholder="Search file &amp; directory names.">
    <a id="tree-filter-clear-query" title="Clear current search..."><i class="icon-remove"></i></a>
</div>
<ul class="unstyled" id="tree-filter-results"></ul>
ENDTREESEARCH;

		return $out;
    }
    ##  ------------------------------------------------------	
    function tree($array, $parent, $parts = array(), $step = 0) {
        if (!count($array)) {
            return '';
        }
        
        $sourcelink = '';
	if (isset($_GET['source'])) {$sourcelink = '?source=true'; }
        
        $tid = ($step == 0) ? 'id="tree"' : '';
        $t = '<ul class="unstyled" '.$tid.'>';
        foreach ($array as $key => $item) {

            if (is_array($item)) {
                $open = $step !== false && (isset($parts[$step]) && $key == $parts[$step]);
                $dirnamefromindex = $key;
                if (isset($item['index'])) $dirnamefromindex = $this->pages[$item['index']]['title'];
                $t .= '<li class="directory'. ($open ? ' open' : '') .'">';
                $t .= '<a href="#" data-role="directory"><i class="icon icon-folder-'. ($open ? 'open' : 'close') .'"></i> ' . $dirnamefromindex . '</a>';
                $t .= $this->tree($item, "$parent/$key", $parts, $open ? $step + 1 : false);
                $t .=  '</li>';
            } else {
                $linktext = $this->pages[$item]['title'];
                $linkpage = basename($this->pages[$item]['filename']);
                $selected = (isset($parts[$step]) && $linkpage == $parts[$step]);
                $linkurl = $parent .'/'. $linkpage . $sourcelink;
                $t .= '<li class="file'. ($selected ? ' active' : '') .'"><a href="'. $linkurl . '">'.$linktext.'</a></li>';
            }
        }

        $t .= '</ul>';

        return $t;
    }	
  
    ##  ------------------------------------------------------
	//to be added to twig var    
	function getjava()
	{
		$out = <<<ENDJAVA
<script>
    // Case-insensitive alternative to :contains():
    // All credit to Mina Gabriel:
    // http://stackoverflow.com/a/15033857/443373
    $.expr[':'].containsIgnoreCase = function (n, i, m) {
        return jQuery(n).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
    };

    $(document).ready(function() {
        var iconFolderOpenClass  = 'icon-folder-open',
            iconFolderCloseClass = 'icon-folder-close',

            // Handle live search/filtering:
            tree             = $('#tree'),
            resultsTree      = $('#tree-filter-results')
            filterInput      = $('#tree-filter-query'),
            clearFilterInput = $('#tree-filter-clear-query')
        ;

        // Auto-focus the search field:
        // jdf: removed the focus since low in sidebar causes page jump.
        //filterInput.focus();

        // Cancels a filtering action and puts everything back
        // in its place:
        function cancelFilterAction()
        {
            filterInput.val('').removeClass('active');
            resultsTree.empty();
            tree.show();
        }

        // Clear the filter input when the X to its right is clicked:
        clearFilterInput.click(cancelFilterAction);

        // Same thing if the user presses ESC and the filter is active:
        $(document).keyup(function(e) {
            e.keyCode == 27 && filterInput.hasClass('active') && cancelFilterAction();
        });

        // Perform live searches as the user types:
        // @todo: check support for 'input' event across more browsers?
        filterInput.bind('input', function() {
            var value         = filterInput.val(),
                query         = $.trim(value),
                isActive      = value != ''
            ;

            // Add a visual cue to show that the filter function is active:
            filterInput.toggleClass('active', isActive);

            // If we have no query, cleanup and bail out:
            if(!isActive) {
                cancelFilterAction();
                return;
            }

            // Hide the actual tree before displaying the fake results tree:
            if(tree.is(':visible')) {
                tree.hide();
            }

            // Sanitize the search query so it won't so easily break
            // the :contains operator:
            query = query
                        .replace(/\(/g, '\\(')
                        .replace(/\)/g, '\\)')
                    ;

            // Get all nodes containing the search query (searches for all a, and returns
            // their parent nodes <li>).
            resultsTree.html(tree.find('a:containsIgnoreCase(' + query + ')').parent().clone());
        });

        // Handle directory-tree expansion:
        $(document).on('click', '#sidebar a[data-role="directory"]', function (event) {
            event.preventDefault();

            var icon = $(this).children('.icon');
            var open = icon.hasClass(iconFolderOpenClass);
            var subtree = $(this).siblings('ul')[0];

            icon.removeClass(iconFolderOpenClass).removeClass(iconFolderCloseClass);

            if (open) {
                if (typeof subtree != 'undefined') {
                    $(subtree).slideUp({ duration: 100 });
                };
                icon.addClass(iconFolderCloseClass);
            } else {
                if (typeof subtree != 'undefined') {
                    $(subtree).slideDown({ duration: 100 });
                }
                icon.addClass(iconFolderOpenClass);
            }
        });
    });
</script>
ENDJAVA;

		return $out;
	}
        ##  ------------------------------------------------------
        protected function _getTreePico2($dir = CONTENT_DIR)
        {
		//no need to scandir; we already have pages
		//HOWEVER,  WE SHOULD BE ABLE TO use $dir, right now not using it!!
            $items = $this->pages;  
            $results=array();
		/* Exclude zonefiles if set 
		   Here may add some other types of excluded files
		*/
		$skipfiles = array();
		if(isset($this->config['zones'])) {
				$skipfiles = array_values($this->config['zones']);
                }
        
            foreach ($items as $key=>$item) {
                //strip the base path
                //get parts
                //  echo '<pre>'; print_r($item); echo '</pre>';
                //$tmp = substr($item['url'], strlen($this->config['base_url'])+1);
                $tmp = $item['url'];
                //echo $item['url']; echo '<br>';
                //echo $this->config['base_url']; echo '<br>'; 
                //echo $tmp.'<br>';
                $parts = explode('/', $tmp);
                 // print_r($parts);
                 /*
                 Some files should not be in menus.......
                Maybe add an exclude config or a page var.
                    
                */
                if (in_array(end($parts), $skipfiles)) $skip = true; else $skip = false;
 
                if(!$skip){
                    //print_r($results);
                    $this->array_set($results, $tmp,  $key);  //store key from pages folder
                }
            }
	
            $newresults = array();
            //get the folders to shwo at the top of the tree above individual files.
            $dummyresult = $this->arraytop($results, $newresults);
            return $newresults;
        }
        ##  ------------------------------------------------------
	function arraytop($array1, &$tmpfolder)
	{
			$tfolder = array();
			$tpage = array();
			foreach ($array1 as $key=>$item) {
				if (is_array($item))
				{
					//echo $key;
					$tfolder[$key] = $item;
					 $this->arraytop($item, $tfolder[$key]);
				}
				else
				{
					$tpage[$key] =$item;
				}
			//$newarray = $tfolder + $tpage;	//folders above files
			$newarray = $tpage + $tfolder;	//files above folders
			$tmpfolder = $newarray;	
			}
			// this is a not used result of no value!
			// the real result of this function is the &tmpfolder
	}
        ##  ------------------------------------------------------
        /*	
	http://stackoverflow.com/questions/3145068/set-multi-dimensional-array-by-key-path-from-array-values
	$value = array_get($arr, 'this/is/the/path');
	$value = array_get($arr, array('this', 'is', 'the', 'path'));
	array_set($arr, 'here/is/another/path', 23);
        */
        function array_get($arr, $path)
        {
            if (!$path) {
                return null;
            }
            $segments = is_array($path) ? $path : explode('/', $path);
            $cur =& $arr;
            foreach ($segments as $segment) {
                if (!isset($cur[$segment])) {
                    return null;
                }
                $cur = $cur[$segment];
            }

            return $cur;
        }
        ##  ------------------------------------------------------
        function array_set(&$arr, $path, $value)
        {
            if (!$path) {
                return null;
            }
            $segments = is_array($path) ? $path : explode('/', $path);
            $cur =& $arr;
            foreach ($segments as $segment) {
                if (!isset($cur[$segment])) {
                        $cur[$segment] = array();
                }
                $cur =& $cur[$segment];
            }
            $cur = $value;
        }	
}
