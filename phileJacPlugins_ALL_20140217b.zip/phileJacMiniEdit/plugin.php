<?php
/**
 * PhileJacMiniEdit:  Minor tweaks to the Phile system Meta Data
 * Class  PhileJacMiniEdit 
 * *******************************************************************************

 */
class PhileJacMiniEdit extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

	// $this->settings will be filled with the data from the config.php file from the plugin folder
	// var_dump($this->settings);
	public function __construct() {
            \Phile\Event::registerEvent('config_loaded', $this);	
            \Phile\Event::registerEvent('request_uri', $this);
            // \Phile\Event::registerEvent('after_load_content', $this);
            \Phile\Event::registerEvent('before_parse_content', $this);;
                 
                 $this->config = \Phile\Registry::get('Phile_Settings');
                 //\Phile\Utility::printnice($this->config, $exit = false, $type = 'print'); 
	
                 $this->showsource = false;
        }

	public function on($eventKey, $data = null) {
            
            if ($eventKey == 'config_loaded') {
                //Event::triggerEvent('config_loaded');                       
                $this->config_loaded();
            }
            if ($eventKey == 'request_uri') {
                //Event::triggerEvent('request_uri', array ($uri)); 
                $this->currentpagename = $data['uri'];
                //builds form html for use in before parse and processes form and header on success post
		//if($uri == 'login') { $this->uriLogin = true;   $this->do_login(); }  
		//if($uri == 'logout'){ $this->uriLogout = true;  $this->do_logout(); }
            }            
             
            if ($eventKey == 'before_parse_content') {
                //if show source AND current uri then do this..........
                $meta = $data['page']->getMeta()->getAll();
                // \Phile\Utility::printnice($meta['filename'], $exit = false, $type = 'print');
                if(!isset($this->currentpagename)) $this->currentpagename = null;
                if( $meta['filename'] == $this->currentpagename.CONTENT_EXT) {
                    if ($this->showsource == true) {   
                        //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                        //$data['content'] = $this->formcontent;
                        $data['content'] = $this->getsource( $this->currentpagename );
                    }
                }
            }        
        
       }

 	public function config_loaded()
	{
		$this->settings = \Phile\Registry::get('Phile_Settings');;
		//if overridden system wide config, then use system wide config.
		if(!isset($this->settings['enableEDIT'])) $this->settings['enableEDIT'] = true;
		
		//if there was an edit do the action and header to the page

		if( (isset ($_GET['action'])) && ($_GET['action'] == 'edit')) 
		{
			$this->editAction();
                }
		
                if( (isset ($_GET['source'])) && ($_GET['source'] == 'true')) 
		{
		        $this->settings['theme'] = $this->settings['editor']['theme'];
                        $this->showsource = true;
                }		
	}	

        public function getsource($thepagename)  
 { 
 			// read the file from disk to get original source since some plugin may have modified it.			
                //$tmpfile = file_get_contents(CONTENT_DIR . $this->currentpagename.CONTENT_EXT); 
			/*  since want to work wit twig as well as php putting it here.  
			*/
                $pageRespository = new \Phile\Repository\Page(); //could use options here
                //$thepages  = $pageRespository->findAll();         
                $page = $pageRespository->findByPath($thepagename);
                /*
                 * jacmgr added method to PAGE MODEL:  getRawData() returne the full raw page from file_get_contents.
                 *        The variable $page->rawData already exists in model, but is protected and there was no get
                 * jacmgr added method to PAGE MODEL:  getContentRaw() returns raw page with stripped meta.
                 *        The variable $page->content already exists in model, but there was no get for it. 
                 */
                 //\Phile\Utility::printnice($page->getContentRaw(), $exit = false, $type = 'print');
                 //\Phile\Utility::printnice($page->getRawData(), $exit = false, $type = 'print');
                 $tmpfile = $page->getRawData();     
    if($this->settings['auth']['admin'] != true) $this->settings['enableEDIT'] = false;  //override, if true and not logged in.
    $out = '<div id="source">';
   
    if ($this->settings['enableEDIT']) :
    
           $out .=' <div class="alert alert-info">
                <i class="icon-pencil"></i> <strong>Editing is enabled</strong>. Use the "Save changes" button below the editor to commit modifications to this file.
            </div>';
    endif;
    
    $out .='<form method="POST" action="'.$this->settings['base_url'] .'/?action=edit'.'">';
    $out .='<input type="hidden" name="ref" value="'.base64_encode($this->currentpagename.CONTENT_EXT).'">';
    $out .='<textarea id="editor" name="source" class="input-block-level" rows="'.(substr_count($tmpfile, "\n") + 1).'">'.$tmpfile.'</textarea>';

   if ($this->settings['enableEDIT']) :
    $out .='<div class="form-actions">';
    $out .='   <input type="submit" class="btn btn-inverse" value="Save Changes">';
    $out .='</div>';
   endif;
    
   $out .='</form>';
   $out .='</div>';	
			
			//$tmp =  htmlentities($tmpfile); 
			
			//$viewproc_vars['content'] = $out; // '<div id="render"><pre><code>'.$tmp.'</code></pre></div>';

 	  	$addjava = null;     

	  	$addjava .='<script>
        $(\'#render pre\').addClass(\'prettyprint linenums\');
        prettyPrint();

        $(\'#render a[href^="#"]\').click(function(event) {
            event.preventDefault();
            document.location.hash = $(this).attr(\'href\').replace(\'#\', \'\');
        });
    			</script>';
    
    	$addjava .= $this->getjava();
    
        $out .= $addjava;
    	/*
    	This is stll going to gp through the parser, but nothing should happen sione htmlentities.....
    	*/
    	return $out;  	 
  
 }
        
 
 
 function getjava($extension='md')
	{
		$readOnly = true;
		 if ($this->settings['enableEDIT']) $readOnly = false;
    
		$out = <<<ENDJAVA
<script>

        var mode = false;
        var modes = {
            'md': 'markdown',
            'js': 'javascript',
            'php': 'php',
            'sql': 'text/x-sql',
            'py': 'python',
            'clj': 'clojure',
            'rb': 'ruby',
            'css': 'css',
            'hs': 'haskell',
            'lsh': 'haskell',
            'pl': 'perl',
            'r': 'r',
            'scss': 'sass',
            'sh': 'shell',
            'xml': 'xml',
            'html': 'htmlmixed',
            'htm': 'htmlmixed'
        };
        var extension = '$extension';
        if (typeof modes[extension] != 'undefined') {
            mode = modes[extension];
        }

        var editor = $('#editor');
        editor.prop('data-editor', CodeMirror.fromTextArea(editor[0], {
            mode: mode,
            theme: 'default',
            lineNumbers: true,
            lineWrapping: true,
            readOnly: $readOnly
        }));

        $('#toggle').on('click', function (event) {
            event.preventDefault();

            var source = $('#source');
            var render = $('#render');
            var submit = $('#submit-edit');

            source.toggle();
            render.toggle();

            if (source.is(':visible')) {
                $('#editor').prop('data-editor').refresh();
            }
        });
    </script>
ENDJAVA;
		
		return $out;
	}	
   /**
     * /?action=edit
     * If ENABLE_EDITING is true, handles file editing through
     * the web interface.
     */
    public function editAction()
    {

        // Bail out early if editing isn't even enabled, or
        // we don't get the right request method && params
        // NOTE: $_POST['source'] may be empty if the user just deletes
        // everything, but it should always be set.
        if (!$this->settings['enableEDIT'] || $_SERVER['REQUEST_METHOD'] != 'POST'
            || empty($_POST['ref']) || !isset($_POST['source'])) {
            //$this->_404();
            echo 'SHOULD HAVE A 404 here....editAction line 153ish'; exit;
        }

        $ref    = $_POST['ref'];
        $source = $_POST['source'];
        $file   = base64_decode($ref);
        $path   = realpath(CONTENT_DIR . $file);
        // echo $path; 
        // Check if the file is safe to work with, otherwise just
        // give back a generic 404 aswell, so we don't allow blind
        // scanning of files:
        // @todo: we CAN give back a more informative error message
        // for files that aren't writable...
        if (!$this->_pathIsSafe($path) && !is_writable($path)) {
        	  echo 'SHOULD HAVE A 404 here....editAction line 167ish'; exit;
            $this->_404();
        }

        // Save the changes, and redirect back to the same page:
        file_put_contents($path, $source);
				$ext = CONTENT_EXT;
				$pagename = str_replace($ext, "", $file);
                                
        //echo $source; exit;
        
        $redirect_url = $this->settings['base_url'] . "/$pagename";

        header("HTTP/1.0 302 Found", true);
        header("Location: $redirect_url");

        exit();
    }
    /**
     * Given a file path, verifies if the file is safe to touch,
     * given permissions, if it's within the library, etc.
     *
     * @param  string $path
     * @return bool
     */
    protected function _pathIsSafe($path)
    {
        if($path && strpos($path, CONTENT_DIR) === 0 && is_readable($path)) {
            return true;
        }

        return false;
    }
        
}