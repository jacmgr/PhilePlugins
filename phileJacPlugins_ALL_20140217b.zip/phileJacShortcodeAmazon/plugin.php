<?php
// PhileJacShortcodeAmazon.php
// ---------------------------------------
// The plugin class phileJacShortcode.php must be loaded and activated before all shortcodes.
// The shortcodes are executed in the hook before_parse_content OF phileJacShortcode.php.
/*
   AMAZON
[linkiframeAmazon asins=0547517653]

*/
// ---------------------------------------
// See other files for more shortcodes
// ---------------------------------------
class PhileJacShortcodeAmazon extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
  /*
  NOTE: SHORTCODES ARE DONE BEFORE MARKDOWN......
  */
	public function __construct() {
                //register the shortcode in phileJacShortcode.php do_shortcode
                //this format for functions that are in an object
		add_shortcode('linkiframeAmazon', array($this, 'funcIframeAmazon'));   
	}
        
        //each plugin extending plugin\AbstractPlugin MUST have an "on" Method, even if does nothing
      	public function on($eventKey, $data = null) {
            //do nothing for this shortcode
        }

	// The shortcode function registered in constructor.
        public function funcIframeAmazon($atts, $content = null) 
	{
	/*extract( shortcode_atts( array(
		'name' => '',
	), $atts ) );
	*/
	$args = shortcode_atts( array(
		'asins' => '',
		), 
		$atts );
        
                $htmlout = '<iframe src="http://rcm.amazon.com/e/cm?lt1=_blank&bc1=000000&IS2=1&npa=1&bg1=FFFFFF&fc1=000000&lc1=0000FF&t=urichip-20&o=1&p=8&l=as1&m=amazon&f=ifr&ref=tf_til&asins='.$args['asins'].'" style="float:left;width:120px;height:240px; margin-right: 10px;" scrolling="no" marginwidth="0" marginheight="0" frameborder="0"></iframe>';
                return $htmlout;
	}        
}
