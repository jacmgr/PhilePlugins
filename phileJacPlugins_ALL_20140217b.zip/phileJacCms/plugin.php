<?php
// ALSO MODIFIED CORE TO STRIP QUERY STRING.......from URI
// important to strip in core, since cannot modify the uri from plugin.
/**
 * PhileJacCms:  Minor tweaks to the Phile system
 * Class  PhileJacCms <= the class name is the pluginKey but first char uppercase!
 * important: the pluginKey is also the folder name!
 * 
 * 1.  Allow the System to use a SYSTEM folder outside of the site folder.  ALl that is in site folder should be the 
 *     index, config, and direct files related to site.  These DEFINES are made in INDEX.PHP.  I added SYSTEMFOLDER
 *     as a define.  But the TWIG VARS template folder also needs to be adjusted so thems can be in the SYSTEMFOLDER.
 * 
 * 2.  to have relative links properly parsed, the page url must have a real page name in it.  So although
 *     /sitename/subfolder   will properly show the page subfolder/index; any links on the page will be to /sitename
 *     to fix this redirect to sitename/subfolder/index to get the proper relative link
 * 
 */
class PhileJacCms extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

	// $this->settings will be filled with the data from the config.php file from the plugin folder
	// var_dump($this->settings);
	public function __construct() {
                 \Phile\Event::registerEvent('request_uri', $this);
		 \Phile\Event::registerEvent('template_engine_registered', $this);
	}

	public function on($eventKey, $data = null) {
     
		
                if ($eventKey == 'request_uri') {
                    //Event::triggerEvent('request_uri', array('uri' => $uri));
                    //
                    // 1. Strip Query String from URI, so uri is only the page.  Can;t do it here because cannot 
                    // modiy the uri and send back to the core.  There fore
                    // modified core.php initCurrentPage() method just before this callback.
                    // modified core to do this.....????
                    // $uri = preg_replace('/\?.*/', '', $data['uri']); // Strip query string
                    //
                    // 2. problem with markdown relative links when on index page without "index" in the uri.
                    // I donl;t want t habe to give the full baseurl in each markdown link. and I don't want to
                    // have to use a folder name in each markdown link when all the links are to the same folder.
                    // This generally solved the problem.  Just don;t allow link without the "index" page explicite.
                    // for example yoursite.com redirected to yoursite.com/index
                    //             yoursite.com/subfoldername redirected to yoursite.com/subfoldername/index
                    // to minimize the redirects, when code templates and pages use link as "index" instead of '/' etc
                    if (is_dir(CONTENT_DIR . $data['uri'])) {
                        //\Phile\Utility::printnice($data['uri'], $exit = false, $type = 'print');
                        $base_url =  \Phile\Utility::getBaseUrl();
                        $needseperator = '/'; 
                        $needseperator2 = '/';
                        //if top level copntent folder index uri, don't need seperator
                        if($data['uri'] == '') { $needseperator = ''; }
                        if(substr($data['uri'], -1) === '/') { $needseperator2 = ''; }
                        $redirect_url = $base_url .$needseperator. $data['uri'].$needseperator2.'index';
                        //\Phile\Utility::printnice($redirect_url, $exit = false, $type = 'print');
                       
                        \Phile\Utility::redirect($redirect_url, 302);
                        die();
                    }
		}

		if ($eventKey == 'template_engine_registered') {
                    //Event::triggerEvent('template_engine_registered', array('engine' => &$twig, 'data' => &$twig_vars));                   
                    // 1. Set the THEME URL TO THE SYSTEM DIRECTORY
                    // related to using a phile system folder outsode of the main root folder.
                    // phile sets oit to the theme directly, not from a config, so have to overide here.
                    $settings = $data['data']['config'];  //see the trigger for data structure
                    //reset the twig vars {'theme_url']
                    $data['data']['theme_url'] = dirname($settings['base_url']).'/'.SYSTEMFOLDER.'/'. basename(THEMES_DIR) .'/'. $settings['theme'];
                    // 2. I use a content marker to mark the end of my desired excerpts.  Maybe the marker never
                    //    got removed from the content page.  So check and remove.
                    //    remove the [[#ENDSUMMARY]] tag if in the current URI
                    $data['data']['content'] = str_replace('[[#ENDSUMMARY]]', '', $data['data']['content']);
                }
       }
}