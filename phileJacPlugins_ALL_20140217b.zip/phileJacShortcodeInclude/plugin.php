<?php
// PhileJacShortcodeInclude.php
// ---------------------------------------
// The plugin class phileJacShortcode.php must be loaded and activated before all shortcodes.
// The shortcodes are executed in the hook before_parse_content OF phileJacShortcode.php.
/*
   INCLUDE 
   includes another markdown file into content unparsed
   Adds included files meta to current context if not existing in main pages
   does not parse or do variable substitution just merges to single page content
   Can do 1 level recursive include

*/
// ---------------------------------------
// See other files for more shortcodes
// ---------------------------------------
class PhileJacShortcodeInclude extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {
  /*
  NOTE: SHORTCODES ARE DONE BEFORE MARKDOWN......
  */
	public function __construct() {
                //register the shortcode in phileJacShortcode.php do_shortcode
                //this format for functions that are in an object
		add_shortcode('include', array($this, 'funcinclude'));   
	}
        
        //each plugin extending plugin\AbstractPlugin MUST have an "on" Method.
      	public function on($eventKey, $data = null) {
            //do nothing for this shortcode
        }

	// The shortcode function registered in constructor.
        public function funcinclude($atts, $content = null) 
	{
		/*
		$content here is the shortcode content between the short code open and close tag.  It is not the page content.
		This function is called from phileJacShortcode.php do_shortcode function. 
                The end result of $content in this function is what will replace the shortcode tag that
                is parsed in phileJacShortcode.php do_shortcode function.
		
		We are simply combining the markdown from the included file into the current page markdown for later 
                normal parsing.  i.e. just changeing raw content.
		
		*/
		extract( shortcode_atts( array(
		'file' => null,
		'extract' => false,
		'raw'=> false
			), $atts ) );
		if ($raw == 'false') $raw = false;
	
                // defulat page repository object adds .md; so we need to delete here
                //future check if extension NOT .md and include manually, so can include other than .md files
                $file = rtrim($file, ".md");
                
                 $pageRepository = new \Phile\Repository\Page(); //could use options here
                 $thepage  = $pageRepository->findByPath(''.$file);
                 ## \Phile\Utility::printnice($file, $exit = false, $type = 'print');
                 if ($thepage == null){
                     $content = " **included file: $file not found** ";
                     /*
                      * FIND WAY TO INCLUDE non content files
                      * 
                      */
                 }else
                 {
                    /*
                     * jacmgr: added this method to the Pages Model.
                     * 
                     */
                    $content = $thepage->getContentRaw();
                    ## \Phile\Utility::printnice($content, $exit = false, $type = 'print');
                    ## \Phile\Utility::printnice($thepage->getMeta()->getAll(), $exit = false, $type = 'print');
                    ## \Phile\Utility::printnice($thepage->getContentRaw(), $exit = false, $type = 'print');
                 }
                 
                 
                 /*
                  * 
                  * MAY WANT TO MERGE INCLUDED META DATA WITH CURRENT PAGE?
                  */
                 
                 /*
                  * May want to add a 1 level recursive for shortcodes that may be in included file.
                  * 
                  */
                 
		return $content;
	}        
}
