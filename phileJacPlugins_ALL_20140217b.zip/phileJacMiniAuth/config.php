<?php
// phileJacMiniAuth CONFIG
// ---------------------------------------
/* 
 * DON't PUT THIS IN CONFIG, since all seetiings in config are exposed in phile settings.
 * 
 * See FILE jacminiaurth_config.php for setting password
 * 
 * This should be a sha1 hash of your password.
 * Use a tool like http://www.sha1-online.com to generate.
 */
$config = array(
);

return $config;
