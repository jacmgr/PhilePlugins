<?php


class PhileJacMiniAuth extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

        private $is_admin;
	private $plugin_path;
	private $password;
	
	public function __construct()
	{
            ## \Phile\Session::destroy();
            //print_r($_SESSION);
            \Phile\Event::registerEvent('config_loaded', $this);	
            \Phile\Event::registerEvent('request_uri', $this);
            \Phile\Event::registerEvent('after_load_content', $this);
            \Phile\Event::registerEvent('before_parse_content', $this);
            
            $this->loginpagename = 'login';
            $this->uriLogin = false;
            $this->uriLogout = false;
            $this->is_admin = false;
            $this->plugin_path = dirname(__FILE__);
            $this->password = 'PUT PASSWORD IN JACMINIAUTH_CONFIG.PHP';

            if(file_exists($this->plugin_path .'/jacminiauth_config.php')){
			include_once($this->plugin_path .'/jacminiauth_config.php');
			$this->password = $jacminiauth_password;
            }	
             //print_r($_SESSION);
	}

        
        
	public function config_loaded()
	{
            $this->settings = \Phile\Registry::get('Phile_Settings');
            //default is not authed...
            $this->settings['auth']['admin'] = false;
            $this->settings['auth']['loggedin'] = false;
		if( (\Phile\Session::get('phile_logged_in')) && (\Phile\Session::get('phile_logged_in') == true) )
		{
				//which way is correct.....redundant
				$settings['auth']['admin'] = true;
				$settings['auth']['loggedin'] = true;
				//is above set when do below??? chaeck config in main.
				$this->settings['auth']['admin'] = true;
				$this->settings['auth']['loggedin'] = true;
                                
                                echo 'you are logged in......'; exit; die;
                                
		}
             \Phile\Registry::set('Phile_Settings', $this->settings);
            
	}
	
        /*
	 hijack the url only if it is login or logout
	*/


	public function on($eventKey, $data = null) {
             $this->settings = \Phile\Registry::get('Phile_Settings'); 
            if ($eventKey == 'config_loaded') {
                //Event::triggerEvent('config_loaded');                       
                $this->config_loaded();
                ## \Phile\Utility::printnice( $this->settings , $exit = true, $type = 'print'); 
                //$this->config = \Phile\Registry::get('Phile_Settings');
                ## \Phile\Utility::printnice( $this->config , $exit = false, $type = 'print'); 
            }
            if ($eventKey == 'request_uri') {
                //Event::triggerEvent('request_uri', array ($uri)); 
                 \Phile\Utility::printnice( $data , $exit = false, $type = 'print'); 
                $uri = $data['uri'];
 
	//	if($uri == 'login') { $this->uriLogin = true;   $this->do_login(); }
	//	if($uri == 'logout'){ $this->uriLogout = true;  $this->do_logout(); }
            }
            
            if ($this->uriLogin == true) {               
               if ($eventKey == 'before_parse_content') {
                    //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                    if ($this->uriLogin) {
                        //\Phile\Utility::printnice( $data ); 
                        $data['content'] = $this->formcontent;
                    }
                }                
            }
        }
        

}
