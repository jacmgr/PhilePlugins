<?php
/**
 * PhileJacMiniAuth:  Single User Login
 * Class  PhileJacMiniAuth 
 * *******************************************************************************
 * Uses Session Class to store a logged in status in Session
 *          \Phile\Session::set('phile_logged_in', true);
 *          \Phile\Session::set('phile_logged_in', false);
 * * Also puts status in the config/settings registry
 *          $this->settings['auth']['admin'] = false/true;
            $this->settings['auth']['loggedin'] = false/true;
 * Use a page login.md and logout.md  These pages must exist.
 *          FUTURE:  Should be able to make thse virtual pages with no physical page
 *                   Could not get redirect properly working, so stay on login/logout page.
 * Default password is in the plugin folder file jacminiauth_config.php
 * Password NOT put in session or configs
 * 
 */

class PhileJacMiniAuth extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

	private $password;
	
	public function __construct()
	{
            ## \Phile\Session::destroy();  //when debugging may need to do this.
            // print_r($_SESSION);
            
            \Phile\Event::registerEvent('config_loaded', $this);	
            \Phile\Event::registerEvent('request_uri', $this);
            // \Phile\Event::registerEvent('after_load_content', $this);
            \Phile\Event::registerEvent('before_parse_content', $this);
            
            $this->loginpagename = 'login';
            $this->uriLogin = false;
            $this->uriLogout = false;
            $plugin_path = dirname(__FILE__);
                        
            $this->password = 'PUT PASSWORD IN JACMINIAUTH_CONFIG.PHP';
            //LOAD THE PASSWORD FILE
            if(file_exists($plugin_path .'/jacminiauth_config.php')){
			include_once($plugin_path .'/jacminiauth_config.php');
			$this->password = $jacminiauth_password;
            }	
	}

        /*
	 hijack the url only if it is login or logout
	*/

	public function on($eventKey, $data = null) {
             
            if ($eventKey == 'config_loaded') {
                
                //Event::triggerEvent('config_loaded');                       
                $this->config_loaded();
            }
            
            // hijack the url only if it is login or logout uri
            // so save page uri status code so we know later which page we are on
            // sets up some variables to use later in the other events.
            if ($eventKey == 'request_uri') {
                //Event::triggerEvent('request_uri', array ($uri)); 
                $uri = $data['uri'];
                //builds form html for use in before parse and processes form and header on success post
                $this->currentpagename = $data['uri'];
		if($uri == 'login') { $this->uriLogin = true;   $this->do_login(); }  
		if($uri == 'logout'){ $this->uriLogout = true;  $this->do_logout(); }
            }
            
            // if login was true at request_uri, then check the before parse content.
            // this is only to continue displaying the current log in form or logout page.
            if ($this->uriLogin == true) {               
               if ($eventKey == 'before_parse_content') {
                   //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                   
                    $meta = $data['page']->getMeta()->getAll();
                    // \Phile\Utility::printnice($meta['filename'], $exit = false, $type = 'print');
                    if( $meta['filename'] == $this->currentpagename.CONTENT_EXT) {
                        //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                        $data['content'] = '<div class="alert alert-info">'.$this->formcontent.'</div>';
                    }                
                }
            }
            
            if ($this->uriLogout == true) {               
               if ($eventKey == 'before_parse_content') {
                    //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                    $meta = $data['page']->getMeta()->getAll();
                    // \Phile\Utility::printnice($meta['filename'], $exit = false, $type = 'print');
                    if( $meta['filename'] == $this->currentpagename.CONTENT_EXT) {
                        //Event::triggerEvent('before_parse_content', array('content' => &$this->content, 'page' => &$this));
                        $data['content'] = '<div class="alert alert-info">'.$this->formcontent.'</div>';
                    } 
                }                
            }
            
        }
        
	private function config_loaded()
	{
            $this->settings = \Phile\Registry::get('Phile_Settings');
            //default is not authed...
            $this->settings['auth']['admin'] = false;
            $this->settings['auth']['loggedin'] = false;
            // if already logged in then set the settings for use by other plugins
            if( (\Phile\Session::get('phile_logged_in')) && (\Phile\Session::get('phile_logged_in') == true) )
            {
				$this->settings['auth']['admin'] = true;
				$this->settings['auth']['loggedin'] = true;              
            }
            \Phile\Registry::set('Phile_Settings', $this->settings); 
	}
	        
	private function do_login()
	{ 
		if(\Phile\Session::get('phile_logged_in') == false)
		{
			/*
			In the before render, we need to clear content and replace with this login form
			
			*/
			$out = '<form id="login-form" method="post" action="">';
			if (isset($login_error)) $out .= '<p class="error">'. $login_error.'</p>';
			$out .='<label for="password">Password</label><br />';
			$out .='	<input type="password" name="password" id="password" />';
			$out .='	<input type="submit" value="Login" class="btn" />';
			$out .='</form>';
			$this->formcontent = $out;  //will be shown in after render
			//when get php templates won't have to do this way....			
                        // --------------------------------------------------------
			// Process form if it was posted
			if(isset($_POST['password']))
			{
				if(sha1($_POST['password']) == $this->password)
				{
                                    $this->formcontent= "You Have Successfully Logged In";
                                    \Phile\Session::set('phile_logged_in', 1);
                                    $this->settings = \Phile\Registry::get('Phile_Settings');
                                     $this->settings['auth']['admin'] = true;
                                    $this->settings['auth']['loggedin'] = true;
                                    \Phile\Registry::set('Phile_Settings', $this->settings);
                                    \Phile\Session::save();
       //                           $redirect_url = $this->settings['base_url'];
       //                           header("HTTP/1.0 302 Found", true);
       //                           header("Location: $redirect_url");
       //                           exit();  //don;t forget to exit after header.....	
				} 
				else 
				{
                                        //re-display the form.....
					$msg = '<p class=alert> Login Error </p>';
					$this->formcontent= $msg . $this->formcontent;
				}
			} 			
		}
		else
		{
                    //Already logged in
                    $this->formcontent= "You Are Already Logged In";
      //            $redirect_url = $this->settings['base_url'];
      //            header("HTTP/1.0 302 Found", true);
      //            header("Location: $redirect_url");
      //            exit();  //don;t forget to exit after header.....			
		}
	}
	
	private function do_logout()
	{	
            \Phile\Session::set('phile_logged_in', 0);
            $this->settings = \Phile\Registry::get('Phile_Settings');
            $this->settings['auth']['admin'] = false;
            $this->settings['auth']['loggedin'] = false;
            \Phile\Registry::set('Phile_Settings', $this->settings);
            \Phile\Session::save();
            $this->formcontent= "You Are Logged Out";
 //         $redirect_url = $this->settings['base_url'];                       
 //         header('Location: '. $redirect_url);
 //         exit();
	}

}
