<?php
// phileJacMiniAuth CONFIG
// ---------------------------------------
/* 
 * This should be a sha1 hash of your password.
 * Use a tool like http://www.sha1-online.com to generate.
 */
$jacminiauth_password = '2955fd49ac449403370bc639edb9df66fee54a40';
