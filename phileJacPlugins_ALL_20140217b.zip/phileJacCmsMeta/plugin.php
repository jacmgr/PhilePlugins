<?php
/**
 * PhileJacCmsMeta:  Minor tweaks to the Phile system Meta Data
 * Class  PhileJacCmsMeta 
 * *******************************************************************************
		   Adds to meta
		   * if no title makes title the same as filename
		   * add filename to page meta
		   * convert any "date" named meta to a unix time stamp
                   * adds heirarchical meta to folders and subfolders.

        See public function getmeta_in_heirarchy where the list of meta is defined
        This should really be a CONFIG upfront in the plugin!
        $headerlist = array('description' => 'description', 
                            'authorentries' => 'author', 
                            'templateentries' => 'template', 
                            'layoutentries' => 'layout',
                            'commentsentries' => 'comments',
                            'robotsentries' => 'robots',
                            );
 * 
 */
class PhileJacCmsMeta extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

	// $this->settings will be filled with the data from the config.php file from the plugin folder
	// var_dump($this->settings);
	public function __construct() {
		 \Phile\Event::registerEvent('before_load_content', $this);
                 \Phile\Event::registerEvent('after_read_file_meta', $this);
                 \Phile\Event::registerEvent('template_engine_registered', $this);  
                 
                 $this->config = \Phile\Registry::get('Phile_Settings');
                 //\Phile\Utility::printnice($this->config, $exit = false, $type = 'print'); 
	}

	public function on($eventKey, $data = null) {
            
            if ($eventKey == 'before_load_content') {
               //Event::triggerEvent('before_load_content', array('filePath' => &$this->filePath, 'rawData' => $this->rawData, 'page' => &$this)); 
               $this->thispageURL = $data['filePath'];
               // jacmgr: why sometimes url looks like this?  C:\xampp\htdocs\phile\two\content\//sub/page.md
               //fix it so looks like this: C:\xampp\htdocs\phile\two\content\sub/page.md
               $this->thispageURL = str_replace('\/', '\\', $this->thispageURL);
               // \Phile\Utility::printnice('BL: '.$this->thispageURL, $exit = false, $type = 'print'); 
            }
            
            if ($eventKey == 'after_read_file_meta') {
                //Event::triggerEvent('after_read_file_meta', array('rawData' => &$rawData, 'meta' => &$this));
                ## \Phile\Utility::printnice($data['meta']->getAll(), $exit = false, $type = 'print');
                // get all meta for this page in array
                $thispageMETA = $data['meta']->getAll();
  
                // This  already handled by jaccms plugin, could delete ???????          
                // Adjust if url is index
                if (substr($this->thispageURL, -1) == '/') {
                    echo 'some error. in jaccmsmeta and url ends in slash';
                    echo $this->thispageURL;
                    // $this->thispageURL = $this->thispageURL . '/index';
                }
                //
                // Add filename to meta
                $tmp = explode(CONTENT_DIR, $this->thispageURL);
                //should never need this if, since jaccms alread makes sure urls include a filename.
                if (!isset($tmp[1])) {
                     echo 'in cmsmeta and tmp1 not defined'; echo $this->thispageURL;
                     echo $this->thispageURL.'<br>';
                     print_r($tmp);
                 }
                 //add to the meta
                $thispageMETA['filename'] = $tmp[1];
 
                // IF NO TITLE, the set filename as title
                //future maybe: if no title search content for first h1 or h2 and use that
                if(!isset($thispageMETA['title'])) {
                    $thispageMETA['title'] = ''; //null;
                }
                if (($thispageMETA['title'] === null) || ($thispageMETA['title'] === "") || ($thispageMETA['title'] === "")) {
                    $thispageMETA['title'] = ucfirst(basename($thispageMETA['filename']));
                }
                 ##\Phile\Utility::printnice($thispageMETA, $exit = false, $type = 'print');
         
                //CONVERT DATE META TO timestamps Makes it easier for sorting in other plugins
                foreach ($thispageMETA as $field => $value) {
                    if (strstr($field, 'date')) {
                        //keeep picobbackward compatible for dateFormat
                        if ($field !='date_formatted'){
                            $thispageMETA[$field] = date('U', strtotime($value));
                        }
                    }
                }

                //SAve the revised meta to the object.
                //$data['meta']->setAll();
                foreach ($thispageMETA as $key => $value) {
			$data['meta']->set($key, trim($value));
		}
		
            }
            
            if ($eventKey == 'template_engine_registered') {
                // Event::triggerEvent('template_engine_registered', array('engine' => &$twig, 'data' => &$twig_vars));
                // SETS The heirarchical meta data for current page
                // layout  *******
                // template
                // comments
                // robots
                // author
                
                //\Phile\Utility::printnice($data['data'], $exit = false, $type = 'print');
                $meta = $data['data']['current_page']->getMeta()->getAll();
                 // \Phile\Utility::printnice($data['data']['current_page']->getMeta()->getAll(), $exit = false, $type = 'print');
                 //added setMeta Function to pages model
                 //$data['data']['current_page']->setMeta('myauthor', 'john');
                 $finfo = pathinfo($meta['filename']);
                 $foldername = $finfo['dirname'];
                 $metafromheirarchy = $this->getmeta_in_heirarchy($foldername);  //custom plugin function below
                 
                 //\Phile\Utility::printnice($metafromheirarchy, $exit = false, $type = 'print');
                 
                 //$meta = array_merge($meta, $metafromheirarchy);
                 $meta = $meta + $metafromheirarchy;
                
                 if ( array_key_exists('layout', $meta)){
                    $meta['template'] = $meta['layout'];
                 } 
                 foreach( $meta as $key => $value ) {
                    $data['data']['current_page']->setMeta($key, $value);
                 }

                 //\Phile\Utility::printnice($data['data']['current_page']->getMeta()->getAll(), $exit = false, $type = 'print');       
            }            
 
          
       }

       
       // # =====================================================================
    public function getmeta_in_heirarchy($foldername = null) {
        $headerlist = array('description' => 'description', 
                            'authorentries' => 'author', 
                            'templateentries' => 'template', 
                            'layoutentries' => 'layout',
                            'commentsentries' => 'comments',
                            'robotsentries' => 'robots',
                            );
        

                
                 $pageRepository = new \Phile\Repository\Page(); //could use options here

        
        $meta = array();
        //$currentdir is something like /docs or /docs/subfolder or /
        $tree0 = explode('/', $foldername);
        $tree[] = '';
        foreach ($tree0 as $item) {
            $tree[] = $item;
        }
        $startfolder = '';
        foreach ($tree as $folder) {
            $filedelim = '/';
            if ($folder == '') {
                $filedelim = '';
            }

            $filelook = $startfolder . $folder . $filedelim . 'index';
            //echo $filelook .'<hr>';
            $thepage  = $pageRepository->findByPath($filelook);
                 // ## \Phile\Utility::printnice($file, $exit = false, $type = 'print');
                 // if ($thepage == null){ echo 'page not found';}
                 
            //if (isset($this->pages[$filelook])) {
            if ($thepage) {
                /*
                $tmpmeta = $this->pages[$filelook];
                unset($tmpmeta['content']);
                unset($tmpmeta['excerpt']);
                */
                $tmpmeta = $thepage->getMeta()->getAll();
                
                
                foreach ($tmpmeta as $key => $value) {
                    if (array_key_exists($key, $headerlist)) {
                        $meta[$headerlist[$key]] = $value;
                    }
                }
            }
            $startfolder = $startfolder . $folder . $filedelim;
        }
        return $meta;
    }
// # ================================================
}
/*
// PUT THIS IN THE philejaccms plugin...... template engine registered event.
                        // in plugin use check template, and if not then reset the meta.
                        //jacmgr if template does not exist, use index.  Possibility is that using the template variable simply as a flag
                        $usetemplate = THEMES_DIR . $this->settings['theme'].'\\'.$template.'.html';
                        if (!file_exists($usetemplate)) { $template = 'index'; }
*/