<?php

return array(
	'open_tag' => '%', // the open tag for the variable
	'close_tag' => '%' // the close tag for the variable
);
