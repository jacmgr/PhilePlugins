<?php

/**
 * Add custom variables in your content before it is parsed.
 */
class PhileJacContentVariables extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

	public function __construct() {
                \Phile\Event::registerEvent('before_parse_content', $this);
		\Phile\Event::registerEvent('after_parse_content', $this);
		
                // go and get the settings for the site
		$this->config = \Phile\Registry::get('Phile_Settings');

              
	}

	public function on($eventKey, $data = null) {
		 if ($eventKey == 'before_parse_content') {
                    //Event::triggerEvent('before_parse_content', array('content' => $this->content, 'page' => &$this));   
                    ## \Phile\Utility::printnice($data['page']->getMeta(), $exit = false, $type = 'print');                     
                     
                     $allowedconfigvars = array(
				'base_url',
				'site_title',
				'theme',
//				'theme_url',
                    );
                    //assemble the allowed variables from config/settings
                    foreach( $allowedconfigvars as $key )
                    {
			$allowedvars[$key] = $this->config[$key];
                    } 
                    
                    //assemble the META DATA VARS 
                    $metaarray = $data['page']->getMeta()->getAll(); 
                  
                    ## \Phile\Utility::printnice($metaarray, $exit = false, $type = 'print'); 

                    foreach ($metaarray as $key => $value) {
                        $allowedvars[$key]  = $value;
                    }                         
                
                    ## \Phile\Utility::printnice($allowedvars, $exit = false, $type = 'print');   
                     $content = $this->parse_content_variables($data['content'], $allowedvars);  //custom unction below
                    
                    // add the modified content back in the data
                    $data['content'] = $content;
                 }
            
                /*
                 * This from original phile.  I use the beore parse above, so these should all be taken care of
                 * Note I did not implement the $this->settings['open_tag'].$key.$this->settings['close_tag'];
                 * My version always assumes you are using % and my version also provides for escapeing the varname
                 */
                /*
                 if ($eventKey == 'after_parse_content') {
                   //Event::triggerEvent('after_parse_content', array('content' => &$content, 'page' => &$this));
			// check to see if there is even a proper key set
			if (isset($this->config['variables'])) {
				// store the starting content
				$content = $data['content'];
				// find and replace each variable
				foreach ($this->config['variables'] as $key => $value) {
					// add the prepend and append the tags
					$target = $this->settings['open_tag'].$key.$this->settings['close_tag'];
					$content = str_replace($target, $value, $content);
				}
				// add the modified content back in the data
				$data['content'] = $content;
			}
                  }
                 */
	}
	
        private function parse_content_variables($content, $pagevars)
	{
		// using \\% is escaped
		//Make sure vars that were escaped are not converted
                //search content for \% and replace with a unique marker
		$content = str_replace('\\%', '\\jacpercent\\', $content);
		
		foreach( $pagevars as $key => $value )
		{
			$content = str_replace('%'.$key.'%', $value, $content);
		}
		## \Phile\Utility::printnice($content, $exit = false, $type = 'print');     
                
                // Put the escaped variable names back
		$content = str_replace('\\jacpercent\\', '%', $content);		
		return $content;
	}        
        
}
