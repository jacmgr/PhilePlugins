<?php
/*
Any plugin that would be based on shortcode would include the
shortcode functiond from the vendor file
*/
//require_once PICOSYSTEM_DIR.'/vendor/shortcodes/shortcodes.php';
// ---------------------------------------


// error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED );

error_reporting(E_ALL ^ E_DEPRECATED );

require_once PICOSYSTEM_DIR.'/vendor/sql4array/sql4array.class.php';
global $searchtable;
// ---------------------------------------
class Shortcodes_Search {
  public $settings = array();
  public $meta = array();

	public static $recursivestop;
	
	public function __construct()
	{
		
		$this->plugin_path = dirname(__FILE__);
		
		/* may be loop a config variable for allowed shortcodes and add them */
		//this format to add functions that are in this class
		add_shortcode('search', array($this, 'funcsearch'));   
		 self::$recursivestop = 0;
	}
	public function i_need_pico(&$pico)
	{
		$this->pico = &$pico;
	}	
	
	public function config_loaded(&$settings)
	{
		$this->settings = $settings;   //only the initoal program settings doesn;t have settings as they change by plugins etc...
	}

	public function get_pages(&$pages, &$current_page, &$prev_page, &$next_page)
	{
		$this->pages = $pages;   //not worried about prev and next yet.
		return;
	}
	
	public function file_meta(&$meta)
	{
		/*
		passed meta should be same as $this->meta computed in this plugin
		dupplication of effort, but needed it earlier
		also here need to merge the meta with and meta from shortcodes.
		*/
		//echo '<pre>';print_r($this->meta); echo '</pre>';
		$meta =  array_merge($meta, $this->meta);
		//echo '<pre>';print_r($meta); echo '</pre>';
		
		$this->meta = $meta;
	}
	
// ---------------------------------------
// My Core Short Codes [search] and [include]
// ---------------------------------------
/*
   SEARCH, 
   Filters the pages to only those defined in the short Codes
   assigns them to template variable for use in viewproc
   
   optionally if template is specified, then renders it all to content and returns it.

*/
	public function funcsearch($atts, $content = null) 
	{
	extract( shortcode_atts( array(
		'template' => 'linklist',
		'excerpt' => false,
		'addfields' => null,
		'where' => false,
		'count' => null,
		'skip' => 0,
		'paginate' => false,
		'exclude' => null,
	), $atts ) );
	///print_r($atts);
	$somesearchstring = $where;
	//echo $template;
	//echo $count;

//note the false/true is not accuerate it is really like string.  so if not present it is false.  if present it is true...
// that is the way atts work in shortcodes .  very strange   so applies to exceprts to etc...
if ($paginate == false)
{
	//echo "paginate is $paginate   <br>";
	//echo "where is $where  <hr>";
  if ( (isset($_GET['skip'])) && (is_numeric($_GET['skip']) ) ) $skip = $_GET['skip'];
}


	
	/*	
	TAKE IT OUT OF THE SEARCH RESULT.
	IN the index template.
	Add a if the page resultend exists, then show a pagination bar.,
	*/
		
	//echo '<pre>'; echo $out; echo '</pre>';
	
	//THIS ONLY MAKES IT AVAILABLE IN THE INDEX TEMPLATE META.
	//
	/*
	$this->meta['resultend'] = $skip + $count - 1;
	$this->meta['resultstart'] = $skip;
	$this->meta['resultcount'] = $count;
	*/
	/*
	prev and next
	Prev = start - count
	Necxt = end+1
	*/
	/*
	$this->meta['resultprevious'] = $this->meta['resultstart'] - $count; if ($this->meta['resultprevious'] < 0) $this->meta['resultprevious'] = 0;
	$this->meta['resultnext'] = $this->meta['resultend'] + 1;
	//echo '<pre>'; print_r($this->meta); echo '</pre>';	
	*/
	//echo '<pre>'; print_r($this->pages); echo '</pre>';		
	error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED );
			//echo "count is $count";
	
	//echo $exclude;	
	//if want prev and next into the search template have to add it into the function below......
	$out =  $this->mysearch($this->pages, $somesearchstring, $addfields, $template, $excerpt, $count, $skip, $paginate, $exclude);
		   //public function mysearch($pages, $somesearchstring, $addfields, $template, $excerpt, $count, $skip)
	error_reporting(E_ALL ^ E_DEPRECATED );

		//do 1 level recursive in case the include file had shortcodes too..
		//normally shortcode does not use this function, but here we want to do a recursive 
		//echo "<hr>recuresice is ".self::$recursivestop."<br>";
		//echo $out;

		if(self::$recursivestop == 0)
		{
			self::$recursivestop = 1;  //make sure only do once
			
			//$out = do_shortcode($out);
			
			
			//echo "<hr>recuresice is ".self::$recursivestop."<br>";
			//echo $out;
		}

	return $out;
	}
// ---------------------------------------
// Support Functions
// ---------------------------------------
	/**
	 * Parses the file meta from the txt file header
	 *
	 * @param string $content the raw txt content
	 * @return array $headers an array of meta values
	 */
	private function read_file_meta($content)
	{
		$headers = array();
		return $headers;
	}
  
  public function before_render(&$twig_vars, &$twig, &$template) {

				//add the pagination values to the meta values.
        //echo '<pre>';print_r($this->meta); echo '</pre>';
       //echo '<pre>';print_r($twig_vars['meta']); echo '</pre>';
				$meta =  array_merge($twig_vars['meta'], $this->meta);       

        $twig_vars['meta'] = $meta;
  }
  
	public function mysearchfmt_list($results, $fmt='linklist')
	{
		if ($fmt == 'ullist')
		{
			$out = '<ul>';
			foreach ($results as $key=>$page)
			{
				$out .= '<li><a href="'.$this->pages[$page['id']]['url'].'">'.$this->pages[$page['id']]['title'].'</a></li>';
			}
			$out .= '</ul>';
			//return $out;
		}
		else
		{
			/*
		   All formats/templates have the name convention: searchresults_templatename.php/html
		  */
		   //run it through viewproc
		   $template='searchresult_'.$fmt.'.html';  
		   
		   //$template='searchresult_'.$fmt; 
		  
		  
		  
		  // print_r($results);
		  //$this->plugin_path.'/templates';
			// cant do:   $this->viewproc->loader->addPath($this->plugin_path.'/templates');
			//so copy templates to the base theme folder.
			/*
			See if we can view proc the results here.
			$page['excerpt']
			
			*/
			/*foreach ($results as $key => $page)
			{
				print_r($page);
				$viewvars['meta'] = $page;
				$results[$key]['excerpt'] = $jaccms->get_zones($zones = array($page['filename']), $viewvars, $this->viewproc, $this->pages);
				
			}
			*/
		   // using my view class
		   //$out = $this->viewproc->render($template, array('results'=>$results, 'config'=>$this->settings));
		   	//straight twig
		   	$loader = new Twig_Loader_Filesystem(THEMES_DIR . $this->settings['theme']);
				$twig = new Twig_Environment($loader, $this->settings['twig_config']);
		   	//$loader = new Twig_Loader_Filesystem($this->plugin_path);
		   	//echo '<pre>'; print_r($this->viewproc_vars['config']['twig_config']); echo '</pre>';	
		   	//$twig_rss = new Twig_Environment($loader, $this->settings['config']['twig_config']);
		   	//need meta for pagination
		   	$VARSFORVIEW = array('results'=>$results, 
		   												'meta'=>$this->meta,
		   												'config'=>$this->settings);
				//echo '<pre>'; print_r($VARSFORVIEW); echo '</pre>';		
		
				$out = $twig->render($template, $VARSFORVIEW) ; // Render rss.html
			
		        //echo $out; //debug
		  	
		  	//$out = $this->pico->parse_snippet($out);   
		  	   
		   //return $out;
	  }
	  
	  
	  return $out;
	}

	public function mysearch($pages, $somesearchstring, $addfields, $template, $excerpt, $count, $skip, $paginate, $exclude)
	{
		//the default metat data fields.
		$fields = array( 'id', 'title', 'url', 'author', 'date', 'filename');
		/*
		So here we have pages already
		
		
			$_split = explode('/', substr($page['url'], strlen($this->settings['base_url'])+1));
			
			
			So se what we got beolow... no filename..... USe URL like at_navigation to get the filename.....
			
			The array is simple index, 0,1,2,3,4,5,6,
			
			Use SQL to search it!!
		*/
		/* delete large text for debugging purposes
		
		Normally we would have an existing index file. that we could search.  
		This section prepares an index file from the passed pages.  as the passed pages improves 
		to be an index file this section can be reduced.
		* add the current pages index to the array
		* process any date field to be a timedatestamp
		
		* have to rpocess the query where for date functions. currently only does
		LOWER(var), UPPER(var), TRIM(var)
		DATE (datevar)
		
		*/

		//echo 'YO.....<pre>';print_r($this->pages);echo '</pre>';
		
		global $searchtable;
		/*
		 Find way to be static, we don;t want multiple instances; i.e one for each include tag on the page.
		*/
		$sql = new sql4array();
		$tablename = 'searchtable';
    //$searchtable = $this->pages;
    $searchtable = $pages;
 		//echo '<h2>starttable</h2>'; echo '<pre>';print_r($searchtable);echo '</pre>'  ; 
    /*
    modify search table as needed
    
    
    DO THE EXCLUDES HERE.........
    */
    $exclude_array = explode(',', $exclude);
    //echo '<pre>'; print_r($exclude_array); echo '</pre>';
    foreach($searchtable as $key=>$page)
		{
			$searchtable[$key]['content'] = 'deleted';
			$searchtable[$key]['excerpt'] = 'deleted';
			$searchtable[$key]['id'] = $key;  //key to original pages array

   //   have to take each exclude and add / to it
    // then cannot do simple array.  have to see if strpos "/filenamee" is in the key.  DON;t USE MD
    //if so unset it.  doesn;lt matter if it is iun a different folder. exclude all filenames anywhere with same name is OK.
			//echo $searchtable[$key]['filename'].'<br>';
			/*
			if (in_array($searchtable[$key]['filename'], $exclude_array)) {
				echo 'excluding..........'.$searchtable[$key]['filename'].'<br>';
				unset($searchtable[$key]); 
			}
			*/

          //$tmp = substr($item['url'], strlen($this->settings['base_url'])+1);
          $parts = explode('/', $searchtable[$key]['filename']);

					if (in_array(end($parts), $exclude_array)) {
          		//echo 'skipped: '.$searchtable[$key]['filename'].'<br>';
          		unset($searchtable[$key]);
          }
       


		}
		//echo '<h2>starttable</h2>'; echo '<pre>';print_r($searchtable);echo '</pre>';
		$sql->createFromGlobals(); //sql4array looks for arrays in gloabl space
		
		$sqlstringarray[0]= "SELECT id, title, url FROM searchtable";
		$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) = ". strtotime('2013/07/06');	
		//$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) > ". strtotime('1970/07/06');	
		//$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) > ". strtotime('1999/07/06')." AND author LIKE '%%'";
		$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE author LIKE '%j%'";		
		$sqlstring = $sqlstringarray[0];
	
		//echo $somesearchstring.'<br>';
		$orderby = 'title DESC';
		$orderby = 'filename asc';
		
		//$sqlstring = "SELECT id, title, url, author, date, filename FROM searchtable WHERE ".$somesearchstring." ORDER BY $orderby";
		/*
		Need a way to add fields from the shorttag.  So add the order by field to
		we can;t know all the fields that will be in pages, so we use the standard ones., then from the tag we could add more?
		*/
		$fields_use = implode(", ", $fields); //'id, title, url, author, date, filename, sequence';
    $fields_use = $fields_use.', '.$addfields;
    
		$sqlstring = "SELECT $fields_use FROM $tablename WHERE ".$somesearchstring;
		//echo $sqlstring.'<hr>';
		
		$results = $sql->query($sqlstring);
		//echo '<pre>'; var_dump($sql); echo '</pre>';

   
	//echo "count is $count and skip is $skip <hr> ";
		/*
		if ($count != null){
			$lastrecord = count($results);
			if($count+$skip > $lastrecord) {
				$skip = $lastrecord - $count;
			}
			$results = array_slice($results, $skip, $count);
		}
		*/
		if ($count != null){
			$countslice = $count;
			$lastrecord = count($results);
			if($count+$skip > $lastrecord) {
				//$skip = $lastrecord - $count;
				$countslice = $lastrecord - $skip;
			}
			$results = array_slice($results, $skip, $countslice);
		}
		
		//echo '<hr>'.$sqlstring.'<h2>results</h2>'; echo '<pre>';print_r($results);echo '</pre>';
		
		/* rebuild the list to include back in all the meta fields and get excerpt if asked for....*/
    $n = 0;
    foreach($results as $key=>$item)
		{
			$tmp[$n] = $this->pages[$item['id']];
			//echo $this->pages[$item['id']]['date'].' <hr> ';
			/*
				FIX UP THE EXCERPT.  THis should actually be handled by parseing soemday
				to backward compatible with boltwore blog, excerpt goes to END SUMMARRY
		
			*/
			$newexcerpt = explode('[[#ENDSUMMARY]]', $tmp[$n]['content']);
			// If there is an [#ENDSUMMARY] TAG then we use that as exceprt, otherwise goes to the defulat pico exceprt.
			if(count($newexcerpt) > 1) $tmp[$n]['excerpt'] = $newexcerpt[0];
			//$tmp[$n]['excerpt'] = $newexcerpt[0];
			// PREVENT RECURSIVE SEARCH........ in an exceprt.  OCcurs when a page to be exceprted includes the same search as current page!
			// i.e. the inde pages.  Should have excluded them in the first place.
			//if the exceprt has a search term in it that will cause endless loop, so 
			//don;t do if there is search term.
			
			if (strpos($tmp[$n]['excerpt'], '[search ') === false) {
			  //echo '<pre>';print_r($newexcerpt);echo '</pre>';
			  $interim = $tmp[$n]['excerpt'];
				//echo $interim; echo '<hr>';
				$interim = $this->pico->parse_snippet($interim);  //passed by reference will nodufy it.
				//exit;
				$tmp[$n]['excerpt'] = $interim;
			}
			
			//echo $tmp[$n]['excerpt'];echo '<hr>';
			//$tmp[$n]['excerpt'] = do_shortcode($tmp[$n]['excerpt']);
			
			$n++;
    }
    
		$results = $tmp;


		//echo '<h2>results</h2>'; echo '<pre>';print_r($results);echo '</pre>';
    //echo $template;
    //add count and skip to the template data....... since template may have a paginator
	//
	$this->meta['resultend'] = $skip + $count - 1;
	$this->meta['resultstart'] = $skip;
	$this->meta['resultcount'] = $count;
	$this->meta['resulttotal'] = $lastrecord;
	/*
	prev and next
	Prev = start - count
	Necxt = end+1
	*/
	$this->meta['resultprevious'] = $this->meta['resultstart'] - $count; if ($this->meta['resultprevious'] < 0) $this->meta['resultprevious'] = 0;
	$this->meta['resultnext'] = $this->meta['resultend'] + 1;
	
	
	//echo '<pre>'; print_r($this->meta); echo '</pre>';	    
  
  //echo '<pre>'; print_r($results); echo '</pre>';
  
  $out = $this->mysearchfmt_list($results, $template);


		/*
		 modify results for retiurn
		 either:
		 return list of pages
		 return link list
		 return a viewproc rendered array
		 just put the result in viewproc var space.
		 
		
		*/
		//echo $out;
		//$out = $this->pico->parse_snippet($out);
		
		 //$out = do_shortcode($out);
		return $out;
	}



}

