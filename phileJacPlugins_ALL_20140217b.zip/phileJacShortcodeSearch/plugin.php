<?php

// PhileJacShortcodeSearch.php
// ---------------------------------------
// The plugin class phileJacShortcode.php must be loaded and activated before all shortcodes.
// The shortcodes are executed in the hook before_parse_content OF phileJacShortcode.php.
/*
  SEARCH
  Searches all files for files meeting passed parameters and formats then as outpit content
 */
// ---------------------------------------
// See other files for more shortcodes
// ---------------------------------------
// error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED );
error_reporting(E_ALL ^ E_DEPRECATED);
//th sql4array library
require_once PLUGINS_DIR . '/phileJacShortcodeSearch/sql4array/sql4array.class.php';
//sql4array requires a gloabal array for searching.
global $searchtable;

//
// ---------------------------------------
class PhileJacShortcodeSearch extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {

    public static $recursivestop;
    public $settings = array();
    public $meta = array();
    public $currentpagename;

    public function __construct() {
        //register the shortcode in phileJacShortcode.php do_shortcode
        //this format for functions that are in an object
        add_shortcode('search', array($this, 'funcsearch'));

        self::$recursivestop = 0;
        //\Phile\Event::registerEvent('config_loaded', $this);
        \Phile\Event::registerEvent('request_uri', $this);
        // \Phile\Event::registerEvent('after_load_content', $this);
        //\Phile\Event::registerEvent('before_parse_content', $this);
    }

    //each plugin extending plugin\AbstractPlugin MUST have an "on" Method.
    public function on($eventKey, $data = null) {
        //do nothing for this shortcode, the master shortcode plugin phileJacShortcode.php
        //will do the shortcode functions.
        if ($eventKey == 'request_uri') {
            //Event::triggerEvent('request_uri', array ($uri)); 
            $this->settings = \Phile\Registry::get('Phile_Settings');
            //\Phile\Utility::printnice($this->settings, $exit = false, $type = 'print'); 
            $this->currentpagename = $data['uri'];
        }
    }
 // ---------------------------------------
// My Core Short Codes [search] and [include]
// ---------------------------------------
    /*
      SEARCH,
      Filters the pages to only those defined in the short Codes
      assigns them to template variable for use in viewproc

      optionally if template is specified, then renders it all to content and returns it.

     */
    public function funcsearch($atts, $content = null) {
        extract(shortcode_atts(array(
            'template' => 'linklist',
            'excerpt' => false,
            'addfields' => null,
            'where' => false,
            'count' => null,
            'skip' => 0,
            'paginate' => false,
            'exclude' => null,
                        ), $atts));

        $somesearchstring = $where;
        //echo $template;
        //echo $count;
        //note the false/true is not accuerate it is really like string.  so if not present it is false.  if present it is true...
        // that is the way atts work in shortcodes .  very strange   so applies to exceprts to etc...
        if ($paginate == false) {
            if ((isset($_GET['skip'])) && (is_numeric($_GET['skip']) ))
                $skip = $_GET['skip'];
        }

        // SET UP THE NEED SEARCH ARRAY:  FUTURE FIND A WAY TO CACHE THIS
        $this->prepare_pagesArray();  //creates $this->pages
		
        error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED);

        $out = $this->mysearch($this->pages, $somesearchstring, $addfields, $template, $excerpt, $count, $skip, $paginate, $exclude);
        
        
        
        error_reporting(E_ALL ^ E_DEPRECATED);

        //do 1 level recursive in case the include file had shortcodes too..
        //normally shortcode does not use this function, but here we want to do a recursive 
        //echo "<hr>recuresice is ".self::$recursivestop."<br>";
        //echo $out;

        if (self::$recursivestop == 0) {
            self::$recursivestop = 1;  //make sure only do once
            //$out = do_shortcode($out);
            //echo "<hr>recuresice is ".self::$recursivestop."<br>";
            //echo $out;
        }

        return $out;
    }

// ---------------------------------------
// Support Functions
// ---------------------------------------

    public function prepare_pagesArray() {
        /*
          This will also get all pages, but since we already have from twig vars $data we use that one.
          Notes:  repository getall pages supports these options.
          $options['pages_order_by'])  alpha, title, date, null (default), meta:fieldname
          $options['pages_order']  asc,desc,

         */
        $pageRepository = new \Phile\Repository\Page(); //could use options here
        $thepages = $pageRepository->findAll();
        /*
         * Create a pages array that is used oin this func
         * array[filename][metakey]=metavalue
         * 
         */
        foreach ($thepages as $page) {
            $id = $page->getUrl();
            $this->pages[$id] = $page->getMeta()->getAll();
            $this->pages[$id]['url'] = $id;
            $this->pages[$id]['filename'] = $id;
            $this->pages[$id]['id'] = $id;
        }

        // \Phile\Utility::printnice($this->pages, $exit = false, $type = 'print'); 

        return;
    }


    public function mysearch($pages, $somesearchstring, $addfields, $template, $excerpt, $count, $skip, $paginate, $exclude) {
        
        //SQL4ARRAY uses a global array as the array it searchs
        // will take pages and modify it into searchtable
        global $searchtable;
        // Find way to be static, we don;t want multiple instances; i.e one for each include tag on the page.
        $sql = new sql4array();
        $tablename = 'searchtable';
        //$searchtable = $this->pages;
        $searchtable = $pages;
        //echo '<h2>starttable</h2>'; echo '<pre>';print_r($searchtable);echo '</pre>'  ;
        //\Phile\Utility::printnice( $searchtable, $exit = false, $type = 'print'); 
        //the default metat data fields to be used in search.
        $fields = array('id', 'title', 'url', 'author', 'date', 'filename');

        /*
          Normally we would have an existing index file. that we could search.
          This section prepares an index file from the passed pages.  as the passed pages improves
          to be an index file this section can be reduced.
         * add the current pages index to the array
         * process any date field to be a timedatestamp
         * have to rpocess the query where for date functions. currently only does
          LOWER(var), UPPER(var), TRIM(var)
          DATE (datevar)
         */

        // modify search table as needed
        // DO THE EXCLUDES HERE.........
        $exclude_array = explode(',', $exclude);
        foreach ($searchtable as $key => $page) {
            $parts = explode('/', $searchtable[$key]['filename']);

            if (in_array(end($parts), $exclude_array)) {
                //echo 'skipped: '.$searchtable[$key]['filename'].'<br>';
                unset($searchtable[$key]);
            }
        }
        
        //begin sql4array operations
        $sql->createFromGlobals(); //sql4array looks for arrays in gloabl space
        // SAMPLE SEARCH STRINGS
        //$sqlstringarray[0] = "SELECT id, title, url FROM searchtable";  //just the basis
        //$sqlstringarray[0] = "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) = " . strtotime('2013/07/06');
        //$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) > ". strtotime('1970/07/06');	
        //$sqlstringarray[0]= "SELECT id, title, url, author, date FROM searchtable WHERE DATE(date) > ". strtotime('1999/07/06')." AND author LIKE '%%'";
        //$sqlstringarray[0] = "SELECT id, title, url, author, date FROM searchtable WHERE author LIKE '%j%'";
        // $sqlstring = $sqlstringarray[0];

        //Just put order by in the shortcode text, not processed here...
        //$orderby = 'title DESC';
        // $orderby = 'filename asc';
        //$sqlstring = "SELECT id, title, url, author, date, filename FROM searchtable WHERE ".$somesearchstring." ORDER BY $orderby";
        /*
          we can't know all the fields that will be in pages, so we use the standard ones., then from the tag we could add more?
         */
        $fields_use = implode(", ", $fields); //'id, title, url, author, date, filename, sequence';
        if($addfields) $fields_use = $fields_use . ', ' . $addfields;

        $sqlstring = "SELECT $fields_use FROM $tablename WHERE " . $somesearchstring;
        //echo $sqlstring.'<hr>';
        //execute the search
        $results = $sql->query($sqlstring);
        // slice so just the number of results requested.
        if ($count != null) {
            $countslice = $count;
            $lastrecord = count($results);
            if ($count + $skip > $lastrecord) {
                //$skip = $lastrecord - $count;
                $countslice = $lastrecord - $skip;
            }
            $results = array_slice($results, $skip, $countslice);
        }
// \Phile\Utility::printnice($results, $exit = false, $type = 'print'); 
        // rebuild the list to include back in all the meta fields and get excerpt if asked for.... 
        $n = 0;

        $pageRepository = new \Phile\Repository\Page(); //could use options here

        foreach ($results as $key => $item) {
            //$tmp[$n] = $this->pages[$item['id']];
            $resultpage = $pageRepository->findByPath($item['id']);
            //$tmp[$n]['content'] = $resultpage->getContentRaw();
            
            $item['content'] = $resultpage->getContentRaw();
            //echo $this->pages[$item['id']]['date'].' <hr> ';
            /*
              FIX UP THE EXCERPT.  THis should actually be handled by parseing soemday
              to backward compatible with boltwore blog, excerpt goes to END SUMMARRY

             */
            $newexcerpt = explode('[[#ENDSUMMARY]]', $item['content']);
            //$newexcerpt = explode('[[#ENDSUMMARY]]', $tmp[$n]['content']);
            // If there is an [#ENDSUMMARY] TAG then we use that as exceprt, otherwise goes to the defulat pico exceprt.
            if (count($newexcerpt) > 1) {
                $item['excerpt'] = $newexcerpt[0];
            } else {
                $word_limit = 50;
                $words = explode(' ', $item['content']);
                $excerpt = trim(implode(' ', array_splice($words, 0, $word_limit)));
                if (count($words) > $word_limit) {
                    $excerpt .= '&hellip;';
                }
                $item['excerpt'] = $excerpt;
            }
            // PARSE THE EXCERPT
            // This basically takes the exceprt and runs the bfore/afterparse and parse
            // PREVENT RECURSIVE SEARCH........ in an exceprt.  OCcurs when a page to be exceprted includes the same search as current page!
            // i.e. the index pages. 
            //if the exceprt has a search term in it that will cause endless loop, so 
            //don't do parse if there is search term in th excerpt, or strip it.
            if (strpos($item['excerpt'], '[search ') === false) {
                $interim = $item['excerpt'];
                $resultpage->setContent($interim);
                $interim = $resultpage->getContent();  //this does the full parseing.....
                $item['excerpt'] = $interim;
            }

            $results[$key]['excerpt'] = $item['excerpt'];
        }

        //add count and skip to the template data....... since template may have a paginator
        //
	$this->meta['resultend'] = $skip + $count - 1;
        $this->meta['resultstart'] = $skip;
        $this->meta['resultcount'] = $count;
        $this->meta['resulttotal'] = $lastrecord;
        /*
          prev and next
          Prev = start - count
          Necxt = end+1
         */
        $this->meta['resultprevious'] = $this->meta['resultstart'] - $count;
        if ($this->meta['resultprevious'] < 0)
            $this->meta['resultprevious'] = 0;
        $this->meta['resultnext'] = $this->meta['resultend'] + 1;

        $out = $this->mysearchfmt_list($results, $template);

        return $out;
    }
    
    public function mysearchfmt_list($results, $fmt = 'linklist') {
        if ($fmt == 'ullist') {
            $out = '<ul>';
            foreach ($results as $key => $page) {
                $out .= '<li><a href="' . $this->pages[$page['id']]['url'] . '">' . $this->pages[$page['id']]['title'] . '</a></li>';
            }
            $out .= '</ul>';
            //return $out;
        } else {
            /*
              All formats/templates have the name convention: searchresults_templatename.php/html
             */
            //run it through viewproc
            $template = 'searchresult_' . $fmt . '.html';

            //straight twig
            //figure out how to use templates in plugin folder if not found in theme folder.
            $loader = new Twig_Loader_Filesystem(THEMES_DIR . $this->settings['theme']);
            //getthese out of the proper config or setting files.
            $TWSETTINGS = array(
                'cache' => false, // To enable Twig caching change this to CACHE_DIR
                'autoescape' => false, // Autoescape Twig vars
                'debug' => true // Enable Twig debug
            );
            $twig = new Twig_Environment($loader, $TWSETTINGS);

            //$templateEngine   = ServiceLocator::getService('Phile_Template');

            //need meta for pagination variables
            $VARSFORVIEW = array(
                            'results' => $results,
                            'meta' => $this->meta,
				'config' => $this->settings,
				'base_dir' => rtrim(ROOT_DIR, '/'),
				'base_url' => $this->settings['base_url'],
				'theme_dir' => THEMES_DIR . $this->settings['theme'],
				'theme_url' => dirname($this->settings['base_url']) .'/'.SYSTEMFOLDER.'/'.  basename(THEMES_DIR) .'/'. $this->settings['theme'],
                                //see jaccms plugin after templateengineregistered.
                                //$data['data']['theme_url'] = dirname($settings['base_url']).'/'.SYSTEMFOLDER.'/'. basename(THEMES_DIR) .'/'. $settings['theme'];
			);
            $out = $twig->render($template, $VARSFORVIEW); // Render rss.html  
            //return $out;
        }

        return $out;
    }

    /*
     * NOT USED ..maybe do this way in future.....
     * Use this if you wanted to get the before/after render hooks as well
     * 
     * 
     */

    public function parse_snippet($snippet) {
        \Phile\Utility::printnice($snippet, $exit = false, $type = 'print');

        $templateEngine = \Phile\ServiceLocator::getService('Phile_Template');

        /**
         * @triggerEvent before_render_template this event is triggered before the template is rendered
         * @param \Phile\Template\TemplateInterface the template engine
         */
        \Phile\Event::triggerEvent('before_render_template', array('templateEngine' => &$templateEngine));

        $templateEngine->setCurrentPage($snippet);
        $output = $templateEngine->render();

        /**
         * @triggerEvent after_render_template this event is triggered after the template is rendered
         * @param \Phile\Template\TemplateInterface the template engine
         * @param string the generated ouput
         */
        \Phile\Event::triggerEvent('after_render_template', array('templateEngine' => &$templateEngine, 'output' => &$output));
        $this->output = $output;
    }
}
