Introduction

	sql4array is a PHP5 class. I have made it in order to apply SQL select queries on PHP arrays.

Features

	Avaible clauses: SELECT, DISTINCT, FROM, WHERE, ORDER BY, LIMIT, OFFSET
	Avaible operators: =, <>, !=, <, >, <=, >=, IS, IS IN, NOT IN, IS NOT IN, LIKE, ILIKE, NOT LIKE, NOT ILIKE
	Functions available in WHERE parameters : LOWER(), UPPER(), TRIM()
	Relatively slow
	Improve visibility of your source code

To do

	add GROUP BY parameters
	add JOIN parameters
	enable functions on select parameters
