<?php
/**
 * Phile pagination
 * proof of concept adapted by jacmgr
 * from:
 * Pico Pagination Plugin
 *
 * @author Andrew Meyer
 * @link http://rewdy.com
 * @license http://opensource.org/licenses/MIT
 * @version 1.2
 */
//class Pagination {
class PhileJacPagination extends \Phile\Plugin\AbstractPlugin implements \Phile\EventObserverInterface {	

    public $config = array();
    public $offset = 0;
    public $page_number = 0;
    public $total_pages = 1;
    public $paged_pages = array();

    public function __construct()
    {

        \Phile\Event::registerEvent('config_loaded', $this);	
        \Phile\Event::registerEvent('request_uri', $this);
        \Phile\Event::registerEvent('before_render_template', $this);;

        $this->showsource = false;
        $this->config = array(
                    'limit' => 5,
                    'next_text' => 'Next >',
                    'prev_text' => '< Previous',
                    'page_indicator' => 'page',
                    'output_format'	=> 'links',
                    'flip_links' => false,
                    'filter_date' => true
            );
    }
    /*
    * ON event method
    */
    //each plugin extending plugin\AbstractPlugin MUST have an "on" Method.
    public function on($eventKey, $data = null) {
        if ($eventKey == 'config_loaded') {
                //Event::triggerEvent('config_loaded');                       
                $this->config_loaded();
        }
        if ($eventKey == 'request_uri') {
            //Event::triggerEvent('request_uri', array ($uri));
            //requires core.php modifiaction to pass by reference so we
            //can strip the url and not get a 404
            //Event::triggerEvent('request_uri', array (&$uri));
            $this->request_url($data['uri']);  //uri will be stripped of parameters
            $this->config['page_url'] = $this->config['base_url'].'/'.$data['uri'];
        }

        if ($eventKey == 'before_render_template') {
                //set up the selected group of pages 
                $this->get_pages();
                //set up the template vars for pagination
                $templatevars = $this->getTwigVars();
                //put template vars in the template
                if (\Phile\Registry::isRegistered('templateVars')) {
                    $template_vars = \Phile\Registry::get('templateVars');
                } else {
                    $template_vars = array();
                }
                $template_vars = array_merge($templatevars, $template_vars);
                \Phile\Registry::set('templateVars', $template_vars);
        }
    }

    /*
    *  load up the settings
    */
    public function config_loaded()
    {
            $settings = \Phile\Registry::get('Phile_Settings');
             //\Phile\Utility::printnice($settings, $exit = false, $type = 'print'); 
            // Pull config options for site config
            if (isset($settings['pagination_limit']))
                    $this->config['limit'] = $settings['pagination_limit'];
            if (isset($settings['pagination_next_text']))
                    $this->config['next_text'] = $settings['pagination_next_text'];
            if (isset($settings['pagination_prev_text']))
                    $this->config['prev_text'] = $settings['pagination_prev_text'];
            if (isset($settings['pagination_flip_links']))
                    $this->config['flip_links'] = $settings['pagination_flip_links'];
            if (isset($settings['pagination_filter_date']))
                    $this->config['filter_date'] = $settings['pagination_filter_date'];
            if (isset($settings['pagination_page_indicator']))
                    $this->config['page_indicator'] = $settings['pagination_page_indicator'];
            if (isset($settings['pagination_output_format']))
                    $this->config['output_format'] = $settings['pagination_output_format'];
            // need in the plugin later
            $this->config['base_url'] = $settings['base_url'];
    }
/*
 * Check the URI
 * 
 */
    //public function get_pages(&$pages, &$current_page, &$prev_page, &$next_page)
    public function get_pages()
    {
        $pageRepository = new \Phile\Repository\Page(); //could use options here
        $pages = $pageRepository->findAll();
            
            // Filter the pages returned based on the pagination options
            $this->offset = ($this->page_number-1) * $this->config['limit'];
            // if filter_date is true, it filters so only dated items are returned.
            if ($this->config['filter_date']) {
                    $show_pages = array();
                    foreach($pages as $key=>$page) {
                            if ($page->getMeta('date')) {
                                    $show_pages[$key] = $page;
                            }
                    }
            } else {
                    $show_pages = $pages;
            }
            // get total pages before show_pages is sliced
            $this->total_pages = ceil(count($show_pages) / $this->config['limit']);
            // slice show_pages to the limit
            $show_pages = array_slice($show_pages, $this->offset, $this->config['limit']);
            // set set filtered pages to paged_pages
            $this->paged_pages = $show_pages;
    }

    /*
     * NOte cannot change uri in phile
     */
    public function request_url(&$url)
    {
        // checks for page # in URL
        $pattern = '/' . $this->config['page_indicator'] . '\//';
        if (preg_match($pattern, $url)) {
                $page_numbers = explode('/', $url);
                $page_number = $page_numbers[count($page_numbers)-1];
                $this->page_number = $page_number;
                //$url = '';   //does nothing for phile since can;t modify uri
                //but modified CORE to accept changed URL
                
                $parts =  explode('/'.$this->config['page_indicator'], $url);

                $url = $parts[0];  //modified requires core change.

        } else {
                $this->page_number = 1;
        }
    }
    /*
     * 
     */   
    //public function before_render(&$twig_vars, &$twig)
    public function getTwigVars()
    {
            // Set a bunch of view vars

            // send the paged pages in separate var
            if ($this->paged_pages)
                    $twig_vars['paged_pages'] = $this->paged_pages;

            // set var for page_number
            if ($this->page_number)
                    $twig_vars['page_number'] = $this->page_number;

            // set var for total pages
            if ($this->total_pages)
                    $twig_vars['total_pages'] = $this->total_pages;

            // build pagination links
            // set next and back link vars to empty. links will be added below if they are available.
            $twig_vars['next_page_link'] = $twig_vars['prev_page_link'] = '';
            $pagination_parts = array();
            if ($this->page_number > 1) {
                    $prev_path = $this->config['page_url'] . '/' . $this->config['page_indicator'] . '/' . ($this->page_number - 1);
                    $pagination_parts['prev_link'] = $twig_vars['prev_page_link'] = '<a href="' . $prev_path . '" id="prev_page_link">' . $this->config['prev_text'] . '</a>';
            }
            if ($this->page_number < $this->total_pages) {
                    $next_path = $this->config['page_url'] . '/' . $this->config['page_indicator'] . '/' . ($this->page_number + 1);
                    $pagination_parts['next_link'] = $twig_vars['next_page_link'] = '<a href="' . $next_path . '" id="next_page_link">' . $this->config['next_text'] . '</a>';
            }

            // reverse order if flip_links is on
            if ($this->config['flip_links']) {
                    $pagination_parts = array_reverse($pagination_parts);
            }

            // create pagination links output
            if ($this->config['output_format'] == "list") {
                    $twig_vars['pagination_links'] = '<ul id="pagination"><li>' . implode('</li><li>', array_values($pagination_parts)) . '</li></ul>';
            } else {
                    $twig_vars['pagination_links'] = implode(' ', array_values($pagination_parts));
            }

            // set page of page var
            $twig_vars['page_of_page'] = "Page " . $this->page_number . " of " . $this->total_pages . ".";
            
            return $twig_vars;
    }
        
}
